
export interface UserProfile {
  fullName: string;
  phone: string;
  email: string;
  address: string;
  joinedDate: string;
  totalAccesses: number;
  recentAccessTimes: string[];
}

export interface CyberLog {
  time: string;
  date?: string; // Added for historical logs
  user: string;
  action: string;
  status: 'Success' | 'Failed';
  oddHour?: boolean;
  profile?: UserProfile;
}

export type CameraMode = 'LIVE' | 'DVR';
export type LogTimeRange = 'LIVE' | 'WEEK' | 'MONTH' | 'YEAR';

export interface CameraData {
  status: 'normal' | 'suspicious';
  behaviour: string;
  time: string;
  confidence: number;
  videoUrl?: string;
  stream?: MediaStream;
  isLive?: boolean;
  mode?: CameraMode; // Tracks if we are in live or DVR playback
}

export interface RiskData {
  score: number;
  physicalScore: number;
  cyberScore: number;
  category: 'LOW' | 'MEDIUM' | 'HIGH';
  color: string;
}

export interface AlertReason {
  type: 'danger' | 'warning' | 'info';
  text: string;
}

export interface AlertData {
  severity: 'low' | 'high';
  title: string;
  subtitle: string;
  reasons: (string | AlertReason)[];
  actionRequired: boolean;
  explainability: string;
  recommendedAction: string;
}

export interface Scenario {
  camera: CameraData;
  cyber: {
    status: 'normal' | 'suspicious';
    logs: CyberLog[];
    anomalies: number;
  };
  risk: RiskData;
  alert: AlertData;
}

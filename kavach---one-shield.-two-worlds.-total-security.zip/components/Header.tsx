
import React from 'react';

interface HeaderProps {
  dateTime: string;
  isThreat: boolean;
  activeScenarioLabel: string;
  onLogoClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ dateTime, isThreat, activeScenarioLabel, onLogoClick }) => {
  return (
    <header className="sticky top-0 z-50 w-full bg-[#0A0E27]/80 backdrop-blur-md border-b border-[var(--primary)]/20 px-6 py-4 flex flex-col md:flex-row justify-between items-center gap-4">
      <div className="flex flex-col md:flex-row items-center gap-4 flex-1">
        <button 
          onClick={onLogoClick}
          className="group relative w-12 h-12 bg-gradient-to-br from-[var(--primary)] to-[var(--secondary)] rounded-xl flex items-center justify-center shadow-[0_0_20px_rgba(var(--primary-rgb),0.3)] shrink-0 transition-all hover:scale-110 active:scale-95 focus:outline-none"
          title="Open Commander Profile"
          style={{ boxShadow: `0 0 20px var(--glow)` }}
        >
          <div className="absolute inset-0 bg-[var(--primary)] rounded-xl blur-xl opacity-0 group-hover:opacity-40 transition-opacity"></div>
          <i className="fa-solid fa-shield-halved text-2xl text-[#0A0E27] relative z-10"></i>
          {/* Subtle activity ping for the logo */}
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-[var(--secondary)] border-2 border-[#0A0E27] rounded-full animate-pulse"></div>
        </button>
        <div className="flex flex-col text-center md:text-left min-w-0">
          <h1 className="text-3xl md:text-4xl font-orbitron font-black uppercase tracking-tighter bg-gradient-to-r from-[var(--primary)] via-[#FFFFFF] to-[var(--secondary)] bg-clip-text text-transparent leading-none drop-shadow-[0_0_10px_var(--glow)]">
            KAVACH
          </h1>
          <div className="flex flex-col mt-1">
            <p className="text-[10px] md:text-xs font-rajdhani font-bold text-[var(--primary)] tracking-[0.2em] uppercase truncate">
              One shield. Two worlds. Total security.
            </p>
            <p className="text-[9px] md:text-[10px] font-rajdhani font-medium text-[#94A3C2]/70 italic tracking-wider truncate">
              Autonomous Cyber-Physical Security Command Center
            </p>
          </div>
        </div>
        
        {/* Operator Protocol Guide - Hidden on mobile, visible on desktop */}
        <div className="hidden xl:flex flex-col items-start gap-1 px-6 border-l border-white/10 ml-4">
          <span className="text-[8px] font-orbitron font-bold text-[var(--primary)]/40 uppercase tracking-widest">System Operator Protocol:</span>
          <p className="text-[10px] font-rajdhani font-black text-white/50 leading-none flex items-center gap-1.5 whitespace-nowrap">
            <span className="text-[var(--primary)]/80">01</span> PICK SCENARIO 
            <i className="fa-solid fa-chevron-right text-[7px] opacity-30"></i> 
            <span className="text-[var(--primary)]/80">02</span> OBSERVE RISK 
            <i className="fa-solid fa-chevron-right text-[7px] opacity-30"></i> 
            <span className="text-[var(--primary)]/80">03</span> ANALYZE LOGS & CAM 
            <i className="fa-solid fa-chevron-right text-[7px] opacity-30"></i> 
            <span className="text-[var(--primary)]/80">04</span> DECIDE ACTION
          </p>
        </div>
      </div>

      <div className="flex items-center gap-6 shrink-0">
        <div className="flex flex-col items-end gap-1">
           <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-[var(--primary)]/10 border border-[var(--primary)]/30">
              <span className="text-[9px] font-orbitron font-bold text-[var(--primary)]/70 uppercase tracking-widest">Current Scenario:</span>
              <span className="text-[10px] font-orbitron font-black text-[var(--primary)] uppercase tracking-widest animate-pulse">{activeScenarioLabel}</span>
           </div>
           <div className="flex items-center gap-3 bg-black/30 px-4 py-1.5 rounded-full border border-white/5">
            <div className={`relative w-2.5 h-2.5 rounded-full ${isThreat ? 'bg-[#FF3366]' : 'bg-[var(--secondary)]'} transition-colors duration-500`}>
              <div className={`absolute inset-0 rounded-full animate-ping opacity-75 ${isThreat ? 'bg-[#FF3366]' : 'bg-[var(--secondary)]'}`}></div>
            </div>
            <span className={`font-orbitron font-bold text-[9px] tracking-widest ${isThreat ? 'text-[#FF3366]' : 'text-[var(--secondary)]'} transition-colors duration-500`}>
              {isThreat ? 'THREAT DETECTED' : 'SYSTEM ACTIVE'}
            </span>
          </div>
        </div>
        
        <div className="hidden md:block h-8 w-px bg-white/10"></div>

        <div className="text-[#94A3C2] font-orbitron font-bold text-xs tracking-widest bg-white/5 px-4 py-2 rounded-lg border border-white/5 min-w-[180px] text-center">
          {dateTime || 'SYNCING...'}
        </div>
      </div>
    </header>
  );
};

export default Header;

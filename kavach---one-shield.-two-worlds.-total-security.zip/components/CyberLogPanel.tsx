
import React, { useState, useMemo } from 'react';
import { Scenario, CyberLog, LogTimeRange } from '../types';
import { HISTORICAL_DATA } from '../constants';

interface CyberLogPanelProps {
  cyber: Scenario['cyber'];
  isAlert?: boolean;
  isAnalyzing?: boolean;
  hasAnalysed?: boolean;
  analysisTimer?: number;
}

const CyberLogPanel: React.FC<CyberLogPanelProps> = ({ cyber, isAlert, isAnalyzing, hasAnalysed, analysisTimer }) => {
  const [filter, setFilter] = useState('');
  const [selectedLog, setSelectedLog] = useState<CyberLog | null>(null);
  const [timeRange, setTimeRange] = useState<LogTimeRange>('LIVE');
  const [isTimeSelectorOpen, setIsTimeSelectorOpen] = useState(false);

  // Status only reveals after analysis is done
  const isRevealedSuspicious = hasAnalysed && (cyber.status === 'suspicious' || isAlert);

  const logsToDisplay = useMemo(() => {
    switch (timeRange) {
      case 'WEEK': return HISTORICAL_DATA.WEEK;
      case 'MONTH': return HISTORICAL_DATA.MONTH;
      case 'YEAR': return HISTORICAL_DATA.YEAR;
      default: return cyber.logs;
    }
  }, [cyber.logs, timeRange]);

  const filteredLogs = useMemo(() => {
    if (!filter) return logsToDisplay;
    return logsToDisplay.filter(log => 
      log.user.toLowerCase().includes(filter.toLowerCase()) || 
      log.action.toLowerCase().includes(filter.toLowerCase()) ||
      (log.profile?.fullName || '').toLowerCase().includes(filter.toLowerCase())
    );
  }, [logsToDisplay, filter]);

  return (
    <div className="panel-blur border-cyan-glow rounded-3xl p-6 lg:p-8 transition-all duration-500 hover:shadow-[0_0_50px_rgba(0,217,255,0.15)] flex flex-col h-full relative group">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-3">
            <button 
                onClick={() => setIsTimeSelectorOpen(!isTimeSelectorOpen)}
                className={`w-10 h-10 rounded-lg flex items-center justify-center transition-all ${
                    timeRange !== 'LIVE' ? 'bg-[#FFB800] text-black shadow-[0_0_20px_#FFB80080]' : 'bg-[#00D9FF]/10 text-[#00D9FF] hover:bg-[#00D9FF]/20'
                } border border-white/5 relative group`}
            >
                <i className={`fa-solid ${timeRange === 'LIVE' ? 'fa-bolt animate-pulse' : 'fa-clock-rotate-left'} text-xl`}></i>
                <div className="absolute -top-8 left-0 px-2 py-1 bg-black/80 rounded text-[7px] font-orbitron font-bold text-white opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">TEMPORAL COMMAND</div>
            </button>
            <div className="flex flex-col">
              <h2 className={`font-orbitron font-bold text-lg tracking-widest uppercase leading-none ${timeRange !== 'LIVE' ? 'text-[#FFB800]' : 'text-[#00D9FF]'}`}>
                {isAnalyzing ? 'Uplink Scanning...' : (timeRange === 'LIVE' ? (hasAnalysed ? 'Live Cyber Feed' : 'Network Standby') : `Archive: ${timeRange}`)}
              </h2>
              <span className="text-[8px] font-mono text-[#94A3C2] uppercase mt-1">
                {isAnalyzing ? `DECODING ENCRYPTED PACKETS [${analysisTimer}s]` : (timeRange === 'LIVE' ? (hasAnalysed ? 'Forensic Verdict Active' : 'Real-time Packet Stream Active') : 'Querying Core Storage Vault')}
              </span>
            </div>
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="hidden lg:flex items-center gap-1 bg-black/40 p-1 rounded-full border border-white/5">
             {(['LIVE', 'WEEK', 'MONTH', 'YEAR'] as LogTimeRange[]).map(range => (
               <button 
                key={range}
                onClick={() => setTimeRange(range)}
                className={`px-3 py-1 rounded-full text-[8px] font-orbitron font-bold transition-all ${
                    timeRange === range 
                    ? 'bg-[#00D9FF] text-black shadow-lg shadow-[#00D9FF]/20' 
                    : 'text-white/40 hover:text-white'
                }`}
               >
                 {range}
               </button>
             ))}
          </div>

          <div className="relative flex-1 sm:flex-initial">
            <input 
              type="text" 
              placeholder="SEARCH DATA..." 
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="bg-black/40 border border-white/10 rounded-full px-4 py-2 text-[10px] font-orbitron text-[#00D9FF] placeholder:text-white/20 focus:outline-none focus:border-[#00D9FF]/50 transition-all w-full sm:w-44"
            />
            <i className="fa-solid fa-search absolute right-4 top-1/2 -translate-y-1/2 text-[10px] text-white/20"></i>
          </div>
        </div>
      </div>

      <div className="relative flex-1 overflow-y-auto no-scrollbar border border-white/10 rounded-xl bg-black/20 mb-4 min-h-[300px] max-h-[500px]">
        {/* TACTICAL ANALYSIS OVERLAY */}
        {isAnalyzing && (
            <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-[#0A0E27]/80 backdrop-blur-[2px] pointer-events-none">
                <i className="fa-solid fa-microchip text-4xl text-[var(--primary)] mb-4 animate-pulse"></i>
                <div className="w-48 h-1 bg-white/10 rounded-full overflow-hidden mb-2">
                    <div className="h-full bg-[var(--primary)] transition-all duration-1000" style={{ width: `${(30 - (analysisTimer || 0)) / 30 * 100}%` }}></div>
                </div>
                <span className="font-orbitron font-black text-[9px] tracking-widest text-[var(--primary)] uppercase">Searching for Anomaly Clusters...</span>
            </div>
        )}

        <table className={`w-full text-left border-collapse min-w-[600px] transition-all duration-1000 ${isAnalyzing ? 'blur-sm grayscale opacity-30' : ''}`}>
          <thead>
            <tr className="border-b border-white/10 bg-white/5 sticky top-0 z-10">
              <th className="p-4 font-orbitron text-[9px] uppercase tracking-widest text-[#94A3C2]">Timestamp</th>
              <th className="p-4 font-orbitron text-[9px] uppercase tracking-widest text-[#94A3C2]">Personnel / Node</th>
              <th className="p-4 font-orbitron text-[9px] uppercase tracking-widest text-[#94A3C2]">Operation</th>
              <th className="p-4 font-orbitron text-[9px] uppercase tracking-widest text-[#94A3C2]">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {filteredLogs.map((log, idx) => {
              // Only highlight threats if analysis is done (reveal)
              const isThreatRow = log.status === 'Failed' || log.oddHour;
              const shouldHighlight = isRevealedSuspicious && isThreatRow;
              
              return (
                <tr 
                  key={`${log.time}-${idx}`} 
                  onClick={() => setSelectedLog(log)}
                  className={`transition-all group cursor-pointer hover:bg-white/5 active:bg-white/10 animate-[rowSlideIn_0.4s_ease-out] ${
                    shouldHighlight ? 'bg-[#FF3366]/20' : (isRevealedSuspicious && isThreatRow ? 'bg-[#FF3366]/10' : '')
                  }`}
                >
                  <td className="p-4">
                      <div className="flex flex-col">
                        <span className={`font-rajdhani text-sm font-semibold ${(log.oddHour && hasAnalysed) ? 'text-[#FFB800]' : 'text-white/80'}`}>{log.time}</span>
                        {log.date && <span className="text-[8px] font-mono text-[#94A3C2] opacity-50 uppercase">{log.date}</span>}
                      </div>
                  </td>
                  <td className="p-4">
                    <div className="flex flex-col">
                      <span className="font-rajdhani text-sm font-bold text-white group-hover:text-[#00D9FF]">
                        {log.profile?.fullName || log.user.toUpperCase()}
                      </span>
                      <span className="text-[9px] font-mono text-[#94A3C2] opacity-50">{log.user}</span>
                    </div>
                  </td>
                  <td className="p-4 font-rajdhani text-sm text-[#94A3C2] italic">
                    {log.action}
                  </td>
                  <td className="p-4">
                    <span className={`px-2 py-0.5 rounded text-[9px] font-orbitron font-bold uppercase border transition-colors duration-1000 ${
                      (log.status === 'Success' || !hasAnalysed)
                        ? 'bg-[#00FF88]/10 border-[#00FF88]/40 text-[#00FF88]' 
                        : 'bg-[#FF3366]/10 border-[#FF3366]/40 text-[#FF3366]'
                    }`}>
                      {(!hasAnalysed) ? 'Success' : log.status}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {filteredLogs.length === 0 && (
          <div className="p-12 text-center text-white/20 font-orbitron text-[10px] tracking-[0.5em] uppercase">NO DATA STREAMS IN THIS RANGE</div>
        )}
      </div>

      <div className={`p-4 rounded-xl border transition-all duration-1000 flex items-center justify-between ${
        isRevealedSuspicious ? 'bg-[#FF3366]/10 border-[#FF3366]/40 shadow-[0_0_20px_rgba(255,51,102,0.1)]' : 'bg-[#00FF88]/10 border-[#00FF88]/40 shadow-[0_0_20px_rgba(0,255,136,0.1)]'
      }`}>
        <div className="flex items-center gap-3">
            <i className={`fa-solid ${isRevealedSuspicious ? 'fa-triangle-exclamation text-[#FF3366]' : 'fa-circle-check text-[#00FF88]'} text-lg ${isRevealedSuspicious ? 'animate-pulse' : ''}`}></i>
            <span className={`font-orbitron font-bold text-xs tracking-widest uppercase ${isRevealedSuspicious ? 'text-[#FF3366]' : 'text-[#00FF88]'}`}>
                {isAnalyzing ? 'Decoding Core Matrix...' : (timeRange === 'LIVE' ? (isRevealedSuspicious ? 'Anomalous Patterns Confirmed' : 'Network Integrity: NOMINAL') : 'ARCHIVE VIEW: READ-ONLY')}
            </span>
        </div>
        <div className="flex flex-col items-end">
           <span className="text-[10px] font-orbitron font-bold text-white leading-none">{isAnalyzing ? 'DECRYPTING' : 'FEED ACTIVE'}</span>
           <span className="text-[8px] font-mono text-[#94A3C2] uppercase mt-0.5">Latency: 24ms</span>
        </div>
      </div>

      {/* Personnel Dossier Modal */}
      {selectedLog && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-[fadeIn_0.2s_ease-out]" onClick={() => setSelectedLog(null)}>
          <div 
            className="bg-[#0D1432] border border-[var(--primary)]/30 rounded-3xl w-full max-w-lg overflow-hidden shadow-[0_0_80px_rgba(0,217,255,0.2)]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 bg-black/40 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-4">
                 <div className="w-12 h-12 rounded-full bg-[var(--primary)]/10 flex items-center justify-center border border-[var(--primary)]/40">
                    <i className="fa-solid fa-user-shield text-xl text-[var(--primary)]"></i>
                 </div>
                 <div>
                    <h3 className="font-orbitron font-black text-xl text-white uppercase leading-tight">Tactical Dossier</h3>
                    <p className="text-[9px] font-orbitron font-bold text-[var(--primary)] tracking-widest uppercase mt-0.5">Personnel ID: {selectedLog.user}</p>
                 </div>
              </div>
              <button 
                onClick={() => setSelectedLog(null)}
                className="w-10 h-10 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center text-white/50 transition-all"
              >
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>

            <div className="p-8 space-y-8 max-h-[70vh] overflow-y-auto no-scrollbar text-white">
              <p className="font-rajdhani text-sm opacity-70">Querying central database for {selectedLog.user}...</p>
              <div className="p-4 bg-white/5 rounded-xl border border-white/10">
                 <span className="text-[9px] font-orbitron text-[#94A3C2] uppercase">Last Operation:</span>
                 <p className="font-orbitron font-bold text-[var(--primary)]">{selectedLog.action}</p>
              </div>
              <button onClick={() => setSelectedLog(null)} className="w-full py-3 bg-[var(--primary)] text-black font-orbitron font-black text-xs rounded-xl">CLOSE DOSSIER</button>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes rowSlideIn {
          from { opacity: 0; transform: translateX(-10px); background: rgba(0, 217, 255, 0.1); }
          to { opacity: 1; transform: translateX(0); }
        }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </div>
  );
};

export default CyberLogPanel;

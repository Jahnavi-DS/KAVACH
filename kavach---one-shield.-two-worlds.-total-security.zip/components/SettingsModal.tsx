
import React from 'react';

export interface SystemConfig {
  autoAnalysis: boolean;
  highFreqLink: boolean;
  biometricBypass: boolean;
}

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  operatorId: string;
  activeTheme: string;
  onThemeChange: (themeName: string) => void;
  config: SystemConfig;
  onToggleConfig: (key: keyof SystemConfig) => void;
  onEmergencyLockdown: () => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ 
  isOpen, 
  onClose, 
  operatorId, 
  activeTheme, 
  onThemeChange,
  config,
  onToggleConfig,
  onEmergencyLockdown
}) => {
  if (!isOpen) return null;

  const themes = [
    { name: 'STEALTH BLUE', primary: '#00D9FF', secondary: '#00FF88' },
    { name: 'CRIMSON ALERT', primary: '#FF3366', secondary: '#FFB800' },
    { name: 'NIGHT VISION', primary: '#00FF88', secondary: '#00D9FF' },
    { name: 'AMBER TACTICAL', primary: '#FFB800', secondary: '#FF3366' }
  ];

  return (
    <div className="fixed inset-0 z-[150] flex items-start justify-start p-4">
      <div className="absolute inset-0 bg-[#0A0E27]/90 backdrop-blur-xl animate-[fadeIn_0.3s_ease-out]" onClick={onClose} />
      
      <div className="relative w-full max-w-md h-full bg-[#0D1432]/95 border-r border-white/10 shadow-[20px_0_50px_rgba(0,0,0,0.8)] flex flex-col animate-[slideRight_0.4s_ease-out] overflow-hidden">
        <div className="absolute top-0 right-0 w-[2px] h-full bg-gradient-to-b from-transparent via-[var(--primary)] to-transparent opacity-50"></div>
        
        <div className="p-8 border-b border-white/10 bg-black/40">
          <div className="flex items-center justify-between mb-2">
            <h2 className="font-orbitron font-black text-2xl tracking-tighter text-[var(--primary)]">OPERATOR PROFILE</h2>
            <button onClick={onClose} className="text-white/40 hover:text-white transition-colors p-2">
              <i className="fa-solid fa-xmark text-xl"></i>
            </button>
          </div>
          <p className="text-[10px] font-orbitron font-bold text-[#94A3C2] tracking-[0.3em] uppercase opacity-50">KAVACH INTERFACE v4.2</p>
        </div>

        <div className="flex-1 overflow-y-auto p-8 space-y-10 custom-scrollbar">
          <section>
            <div className="flex items-center gap-6 p-5 bg-white/5 border border-white/10 rounded-2xl relative shadow-inner">
              <div className="w-16 h-16 rounded-xl bg-[var(--primary)]/10 flex items-center justify-center border border-[var(--primary)]/30">
                <i className="fa-solid fa-user-shield text-2xl text-[var(--primary)]"></i>
              </div>
              <div className="flex flex-col">
                <span className="font-orbitron font-black text-xl text-white tracking-wider">{operatorId || 'GUEST_USER'}</span>
                <span className="text-[10px] font-orbitron font-bold text-[var(--secondary)] uppercase tracking-widest mt-1">CLEARANCE: LEVEL 5</span>
                <span className="text-[9px] font-rajdhani font-bold text-[#94A3C2] uppercase mt-1 opacity-60">HQ: BHARAT-TACTICAL-01</span>
              </div>
            </div>
          </section>

          <section>
            <h3 className="font-orbitron font-bold text-xs text-[var(--primary)] tracking-widest uppercase mb-4 flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-[var(--primary)] animate-pulse"></div>
              TACTICAL INTERFACE THEMES
            </h3>
            <div className="grid grid-cols-2 gap-4">
              {themes.map((t) => (
                <button 
                  key={t.name}
                  onClick={() => onThemeChange(t.name)}
                  className={`flex flex-col items-center gap-2 p-3 bg-black/40 border rounded-xl transition-all ${
                    activeTheme === t.name ? 'border-[var(--primary)] ring-1 ring-[var(--primary)]/50' : 'border-white/10 grayscale hover:grayscale-0 hover:border-white/20'
                  }`}
                >
                  <div className="w-full h-10 rounded-lg shadow-lg" style={{ backgroundColor: t.primary }}></div>
                  <span className={`text-[8px] font-orbitron font-bold ${activeTheme === t.name ? 'text-white' : 'text-white/40'}`}>{t.name}</span>
                </button>
              ))}
            </div>
          </section>

          <section className="space-y-4">
            <h3 className="font-orbitron font-bold text-xs text-[var(--primary)] tracking-widest uppercase mb-6 flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-[var(--primary)]"></div>
              OPERATIONAL PARAMETERS
            </h3>
            
            <div className="space-y-3">
              {[
                { key: 'autoAnalysis' as const, label: 'AI AUTO-SCAN', desc: 'Scan feeds on connection' },
                { key: 'highFreqLink' as const, label: 'SAT-LINK 60HZ', desc: 'High frequency downlink' },
                { key: 'biometricBypass' as const, label: 'BIO-OVERRIDE', desc: 'Force fingerprint re-auth' }
              ].map((item) => (
                <div 
                  key={item.key} 
                  onClick={() => onToggleConfig(item.key)}
                  className="flex items-center justify-between p-4 bg-white/5 border border-white/5 rounded-xl hover:bg-white/10 cursor-pointer transition-all"
                >
                  <div>
                    <p className="text-[10px] font-orbitron font-bold text-white uppercase tracking-wider">{item.label}</p>
                    <p className="text-[9px] font-rajdhani text-[#94A3C2] uppercase mt-0.5">{item.desc}</p>
                  </div>
                  <div className={`w-12 h-6 rounded-full relative p-1 transition-colors ${config[item.key] ? 'bg-[var(--primary)]' : 'bg-white/10'}`}>
                    <div className={`w-4 h-4 rounded-full bg-white transition-transform ${config[item.key] ? 'translate-x-6' : 'translate-x-0'}`}></div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>

        <div className="p-8 border-t border-white/10 bg-black/60 flex flex-col gap-4">
          <button 
            onClick={onEmergencyLockdown}
            className="w-full py-4 bg-red-600 hover:bg-red-500 text-white font-orbitron font-black text-xs tracking-widest uppercase rounded-xl transition-all shadow-lg active:scale-95"
          >
            LOCKDOWN PERIMETER
          </button>
        </div>
      </div>

      <style>{`
        @keyframes slideRight { from { transform: translateX(-100%); } to { transform: translateX(0); } }
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: var(--primary); border-radius: 10px; opacity: 0.3; }
      `}</style>
    </div>
  );
};

export default SettingsModal;

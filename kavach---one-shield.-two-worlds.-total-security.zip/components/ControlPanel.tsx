
import React from 'react';

interface ControlPanelProps {
  activeScenarioLabel: string;
  isAnalyzing: boolean;
  hasAnalysed: boolean;
  analysisTimer: number;
  onAnalyzeNormal: () => void;
  onAnalyzeSuspicious: () => void;
  onSimulateThreat: () => void;
  onToggleLive: () => void;
  onSwitchCamera: () => void;
  onRunAI: () => void;
  onToggleRecording: () => void;
  isRecording: boolean;
  isLive: boolean;
  onUpload: () => void;
  onReset: () => void;
  isExporting?: boolean;
}

const ControlPanel: React.FC<ControlPanelProps> = ({
  activeScenarioLabel,
  isAnalyzing,
  hasAnalysed,
  analysisTimer,
  onAnalyzeNormal,
  onAnalyzeSuspicious,
  onSimulateThreat,
  onToggleLive,
  onSwitchCamera,
  onRunAI,
  onToggleRecording,
  isRecording,
  isLive,
  onUpload,
  onReset,
  isExporting
}) => {
  /**
   * TACTICAL LABEL REVEAL LOGIC:
   * 1. Before Analysis: Show generic node identifiers (RECON-01, RECON-02, RECON-03).
   * 2. During Analysis: Active button shows the countdown (e.g., 30s).
   * 3. After 30 Seconds: The button text changes to the final assessment (SAFE, SUSPICIOUS, THREAT).
   */
  const getScenarioLabel = (base: string) => {
    // Stage 3: Post-Analysis Reveal
    if (hasAnalysed) {
        if (base === 'SUSPICIOUS') return 'SUSPICIOUS';
        return base;
    }

    // Stage 2: Active Analysis Countdown
    if (isAnalyzing && activeScenarioLabel === base) {
        return `${analysisTimer}s`;
    }

    // Stage 1: Pre-Analysis Generic Names
    switch (base) {
      case 'SAFE': return 'RECON-01';
      case 'SUSPICIOUS': return 'RECON-02';
      case 'THREAT': return 'RECON-03';
      default: return base;
    }
  };

  const getScenarioButtonStyle = (base: 'SAFE' | 'SUSPICIOUS' | 'THREAT') => {
    const isTarget = activeScenarioLabel === base;
    
    // Uniform Small Size for all tactical buttons
    const baseClasses = "flex flex-col items-center justify-center w-[82px] h-[54px] rounded-lg transition-all duration-1000 border text-[9px] font-orbitron font-black uppercase";

    // STATE: PRE-ANALYSIS (Light White Tactical Look)
    if (!hasAnalysed) {
      if (isTarget) {
        // Selected button glowing white during scan
        return `${baseClasses} bg-white/20 border-white text-white shadow-[0_0_20px_rgba(255,255,255,0.4)] scale-105 z-10 ring-1 ring-white/30 brightness-110`;
      }
      // Idle light white buttons
      return `${baseClasses} bg-white/5 border-white/20 text-white/40 hover:bg-white/10 hover:border-white/40 hover:text-white/60 shadow-[0_0_10px_rgba(255,255,255,0.05)]`;
    }

    // STATE: POST-ANALYSIS (Target reveals its identity)
    if (!isTarget) {
      return `${baseClasses} bg-white/5 border-white/5 text-white/10 opacity-10 grayscale blur-[1px] pointer-events-none`;
    }

    // Revealed Colors after 30 seconds
    switch (base) {
      case 'SAFE':
        return `${baseClasses} bg-[#008F4C] border-[#00FF88] text-white shadow-[0_0_35px_rgba(0,255,136,0.7)] scale-110 z-10 ring-2 ring-[#00FF88]/40`;
      case 'SUSPICIOUS':
        return `${baseClasses} bg-[#B8860B] border-[#FFB800] text-black shadow-[0_0_35px_rgba(255,184,0,0.7)] scale-110 z-10 ring-2 ring-[#FFB800]/40`;
      case 'THREAT':
        return `${baseClasses} bg-[#B22222] border-[#FF3366] text-white shadow-[0_0_45px_rgba(255,51,102,0.7)] scale-110 z-10 ring-2 ring-[#FF3366]/40`;
    }
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 p-2 md:p-6 z-[60] bg-gradient-to-t from-[#0A0E27] via-[#0A0E27]/90 to-transparent pointer-events-none">
        <div className="max-w-[1400px] mx-auto pointer-events-auto">
            <div className="panel-blur border border-white/10 p-2 rounded-3xl md:rounded-2xl flex flex-col items-center gap-2 shadow-[0_-15px_60px_rgba(0,0,0,0.9)]">
                
                {/* System Diagnostics Line */}
                <div className="hidden md:flex text-[7px] font-orbitron font-bold text-white/20 uppercase tracking-[0.5em] items-center gap-3">
                   <div className="w-12 h-px bg-white/5"></div>
                   {isAnalyzing ? 'UPLINK ESTABLISHED - COMMENCING NEURAL FORENSICS' : hasAnalysed ? 'SCAN COMPLETE - IDENTITY REVEALED' : 'AWAITING NODE SELECTION'}
                   <div className="w-12 h-px bg-white/5"></div>
                </div>
                
                <div className="w-full overflow-x-auto no-scrollbar">
                  <div className="flex items-center justify-start md:justify-center gap-3 px-2 py-1 min-w-max">
                    
                    {/* Compact Uplink Controls */}
                    <div className="flex items-center gap-1.5 bg-white/5 p-1 rounded-xl border border-white/5">
                      <button 
                          onClick={onToggleLive}
                          className={`flex items-center justify-center w-[54px] h-[54px] rounded-lg transition-all duration-300 border ${
                              isLive 
                                ? 'bg-[#FF3366]/20 border-[#FF3366]/40 text-[#FF3366] shadow-[0_0_15px_rgba(255,51,102,0.2)]' 
                                : 'bg-white/10 border-white/10 text-white/50 hover:bg-white/20'
                          }`}
                          title="Toggle Camera Uplink"
                      >
                          <i className={`fa-solid ${isLive ? 'fa-video-slash' : 'fa-camera-retro'} text-xs`}></i>
                      </button>

                      {isLive && (
                        <>
                          <button 
                              onClick={onSwitchCamera}
                              className="flex items-center justify-center w-[54px] h-[54px] bg-white/10 border border-white/10 text-white/80 hover:text-[var(--primary)] rounded-lg transition-all"
                              title="Switch Camera Node"
                          >
                              <i className="fa-solid fa-camera-rotate text-xs"></i>
                          </button>

                          <button 
                              onClick={onToggleRecording}
                              className={`flex items-center justify-center w-[54px] h-[54px] rounded-lg transition-all duration-300 border ${
                                isRecording 
                                  ? 'bg-[#FF3366] border-[#FF3366] text-white shadow-[0_0_15px_rgba(255,51,102,0.6)]' 
                                  : 'bg-white/10 border-white/10 text-white hover:text-[#FF3366]'
                              }`}
                              title="Record Tactical Log"
                          >
                              <i className={`fa-solid ${isRecording ? 'fa-stop-circle' : 'fa-circle'} ${isRecording ? 'animate-pulse' : ''} text-xs`}></i>
                          </button>
                        </>
                      )}
                    </div>

                    <div className="w-px h-8 bg-white/10"></div>

                    {/* Central Analysis Row: All Small & Side-by-Side */}
                    <div className="flex items-center gap-2 p-1 bg-black/40 rounded-xl border border-white/5">
                      
                      {/* SCAN TRIGGER */}
                      {isLive && (
                        <button 
                            onClick={onRunAI}
                            disabled={isAnalyzing}
                            className={`flex flex-col items-center justify-center w-[82px] h-[54px] rounded-lg transition-all duration-500 border ${
                              isAnalyzing 
                                ? 'bg-white/10 border-white/20 text-white/30 opacity-50 cursor-not-allowed' 
                                : 'bg-[var(--primary)] border-[var(--primary)] text-[#0A0E27] shadow-[0_0_20px_rgba(0,217,255,0.4)] active:scale-95'
                            }`}
                        >
                            <i className={`fa-solid ${isAnalyzing ? 'fa-circle-notch fa-spin' : 'fa-brain'} text-xs mb-0.5`}></i>
                            <span className="font-orbitron font-black text-[9px] tracking-widest uppercase leading-none">
                              {isAnalyzing ? 'SCAN' : 'SCAN'}
                            </span>
                        </button>
                      )}

                      {/* NODE SELECTORS: Identical Size, reveal identity after 30s */}
                      <button 
                        onClick={!isAnalyzing ? onAnalyzeNormal : undefined} 
                        className={getScenarioButtonStyle('SAFE')}
                      >
                        <i className={`fa-solid fa-shield-check text-sm mb-0.5 ${activeScenarioLabel === 'SAFE' && isAnalyzing ? 'animate-[spin_2s_linear_infinite]' : ''}`}></i>
                        <span className="tracking-tighter">{getScenarioLabel('SAFE')}</span>
                      </button>

                      <button 
                        onClick={!isAnalyzing ? onAnalyzeSuspicious : undefined} 
                        className={getScenarioButtonStyle('SUSPICIOUS')}
                      >
                        <i className={`fa-solid fa-eye text-sm mb-0.5 ${activeScenarioLabel === 'SUSPICIOUS' && isAnalyzing ? 'animate-bounce' : ''}`}></i>
                        <span className="tracking-tighter">{getScenarioLabel('SUSPICIOUS')}</span>
                      </button>

                      <button 
                        onClick={!isAnalyzing ? onSimulateThreat : undefined} 
                        className={getScenarioButtonStyle('THREAT')}
                      >
                        <i className={`fa-solid fa-radiation text-sm mb-0.5 ${activeScenarioLabel === 'THREAT' && isAnalyzing ? 'animate-[spin_1s_linear_infinite]' : ''}`}></i>
                        <span className="tracking-tighter">{getScenarioLabel('THREAT')}</span>
                      </button>
                    </div>

                    <div className="w-px h-8 bg-white/10"></div>

                    {/* System Utility Hub */}
                    <div className="flex items-center gap-2">
                      <button 
                        onClick={onUpload} 
                        disabled={isExporting} 
                        className={`flex flex-col items-center justify-center w-[74px] h-[54px] border rounded-lg transition-all ${
                          isExporting ? 'bg-white/10 border-white/10 text-white/20' : 'bg-white/5 border-white/10 text-white/60 hover:bg-[var(--primary)] hover:text-black hover:border-[var(--primary)] shadow-sm'
                        }`}
                      >
                          <i className={`fa-solid ${isExporting ? 'fa-circle-notch fa-spin' : 'fa-file-shield'} text-xs mb-0.5`}></i>
                          <span className="font-orbitron font-black text-[8px] uppercase">INTEL</span>
                      </button>

                      <button onClick={onReset} className="w-[54px] h-[54px] flex items-center justify-center bg-white/5 hover:bg-red-500/20 border border-white/5 rounded-lg transition-all group">
                          <i className="fa-solid fa-power-off text-white/20 group-hover:text-red-500 text-xs"></i>
                      </button>
                    </div>

                  </div>
                </div>
            </div>
        </div>
    </div>
  );
};

export default ControlPanel;

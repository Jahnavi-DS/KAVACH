
import React, { useState } from 'react';
import { Scenario } from '../types';

interface ForensicReportProps {
  scenario: Scenario;
  operatorId: string;
  onClose: () => void;
}

const ForensicReport: React.FC<ForensicReportProps> = ({ scenario, operatorId, onClose }) => {
  const [activeTab, setActiveTab] = useState<'REPORT' | 'DISPATCH'>('REPORT');
  const reportId = `KVC-REP-${Math.floor(Math.random() * 900000 + 100000)}`;
  const timestamp = new Date().toLocaleString();
  const dateStr = new Date().toLocaleDateString('en-GB');
  const timeStr = new Date().toLocaleTimeString('en-GB', { hour12: false });
  const location = "Sector 44, Defense Hub, NCR (28.6139° N, 77.2090° E)";
  const mapsLink = "https://maps.google.com/?q=28.6139,77.2090";

  const getThreatType = () => {
    if (scenario.camera.behaviour.includes('WEAPON')) return "Active Physical Threat (Lethal)";
    if (scenario.risk.score > 70) return "High-Level Security Breach";
    if (scenario.risk.score > 30) return "Suspicious Activity / Reconnaissance";
    return "Standard Security Verification";
  };

  const getSignalsSummary = () => {
    const signals = [];
    if (scenario.camera.status !== 'normal') signals.push(`Visual Anomaly: ${scenario.camera.behaviour}`);
    if (scenario.cyber.anomalies > 0) signals.push(`Cyber: ${scenario.cyber.anomalies} unauthorized access attempts`);
    return signals.join(", ") || "None detected";
  };

  // 1. Short prompt for automatic SMS/WhatsApp
  const smsTemplate = `ALERT: Possible threat detected by KAVACH at ${timeStr} on ${dateStr} in ${location}.
Threat type: ${getThreatType()}.
Key signals: ${getSignalsSummary()}.
Risk level: ${scenario.risk.category}.
Requested action: ${scenario.alert.recommendedAction}.
Contact: ${operatorId}, +91-9876543210, command@kavach.ai.`;

  // 2. Long prompt for Email/Formal Report
  const emailTemplate = `Subject: Urgent threat alert from KAVACH – ${getThreatType()} at ${location}

Respected Sir/Madam,
Our safety monitoring system “KAVACH” has detected a potential ${getThreatType()} involving secure sector access.

Date & time of detection: ${dateStr} ${timeStr}
Location (GPS / landmark): ${location}

Detected signals:
- Sensor/AI flags: ${getSignalsSummary()}
- Confidence score: ${scenario.camera.confidence}%
- Recent events: ${scenario.alert.reasons.map(r => typeof r === 'string' ? r : r.text).join("; ")}

Current status of user: ${scenario.alert.actionRequired ? 'IMMEDIATE INTERVENTION REQUIRED' : 'Monitoring under standard protocol'}

Based on these indicators, we request immediate attention: ${scenario.alert.recommendedAction}.

System contact for verification and more data:
Name: ${operatorId}
Role: Tactical Command Operator
Phone: +91-9876543210
Email: alerts@kavach.ai

Kindly treat this as urgent.`;

  // 3. One-line Guardian Panic
  const guardianTemplate = `I may be in danger. My current location: ${mapsLink}. Please try to contact me and inform authorities if needed.`;

  const handlePrint = () => {
    window.print();
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert("Message copied to tactical clipboard.");
  };

  return (
    <div className="fixed inset-0 z-[250] bg-black/95 backdrop-blur-xl flex items-start justify-center overflow-y-auto p-4 md:p-12 no-print-bg">
      <div className="w-full max-w-4xl bg-white text-[#0A0E27] rounded-sm shadow-2xl overflow-hidden flex flex-col animate-[fadeIn_0.5s_ease-out] print:m-0 print:shadow-none min-h-[80vh]">
        
        {/* Classified Ribbon */}
        <div className="bg-[#FF3366] text-white py-1 px-4 flex justify-between items-center font-orbitron text-[10px] font-black uppercase tracking-[0.4em]">
           <span>CONFIDENTIAL // TOP SECRET</span>
           <span className="hidden md:inline">EYES ONLY // COMMAND ACCESS</span>
           <div className="flex gap-4 no-print">
              <button onClick={() => setActiveTab('REPORT')} className={`transition-all ${activeTab === 'REPORT' ? 'underline decoration-2 underline-offset-4' : 'opacity-50 hover:opacity-100'}`}>INTEL REPORT</button>
              <button onClick={() => setActiveTab('DISPATCH')} className={`transition-all ${activeTab === 'DISPATCH' ? 'underline decoration-2 underline-offset-4' : 'opacity-50 hover:opacity-100'}`}>DISPATCH SUITE</button>
           </div>
        </div>

        {activeTab === 'REPORT' ? (
          /* Report Content */
          <div className="p-8 md:p-16 flex-1 space-y-10 font-rajdhani">
            {/* Official Header */}
            <div className="flex flex-col md:flex-row justify-between items-start border-b-4 border-[#0A0E27] pb-8">
               <div className="flex items-center gap-6">
                  <div className="w-20 h-20 bg-[#0A0E27] rounded-lg flex items-center justify-center text-white shrink-0">
                     <i className="fa-solid fa-shield-halved text-5xl"></i>
                  </div>
                  <div className="flex flex-col">
                     <h1 className="font-orbitron font-black text-4xl leading-none mb-1">KAVACH INTELLIGENCE</h1>
                     <p className="font-orbitron font-bold text-xs uppercase tracking-widest opacity-60">Autonomous Defense Infrastructure Report</p>
                  </div>
               </div>
               <div className="mt-6 md:mt-0 text-right">
                  <p className="font-orbitron font-black text-sm uppercase">Reference ID: <span className="text-[#FF3366]">{reportId}</span></p>
                  <p className="text-xs font-bold opacity-70">DATE/TIME: {timestamp}</p>
                  <p className="text-xs font-bold opacity-70">OPERATOR: {operatorId}</p>
               </div>
            </div>

            {/* Executive Summary */}
            <section className="space-y-4">
               <div className="flex items-center gap-4">
                  <h2 className="font-orbitron font-black text-xl uppercase bg-[#0A0E27] text-white px-4 py-1">Executive Summary</h2>
                  <div className="flex-1 h-px bg-[#0A0E27]/20"></div>
               </div>
               <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className={`border-2 p-4 rounded-lg flex flex-col items-center justify-center text-center ${scenario.risk.score > 70 ? 'border-[#FF3366] bg-[#FF3366]/5' : 'border-[#00D9FF] bg-[#00D9FF]/5'}`}>
                     <span className="text-[10px] font-orbitron font-bold uppercase opacity-60">Overall Risk Index</span>
                     <span className="text-5xl font-orbitron font-black">{scenario.risk.score}%</span>
                     <span className={`text-xs font-black uppercase mt-2 ${scenario.risk.score > 70 ? 'text-[#FF3366]' : 'text-[#00D9FF]'}`}>{scenario.risk.category} THREAT</span>
                  </div>
                  <div className="col-span-2 space-y-2">
                     <p className="text-sm font-bold leading-relaxed italic border-l-4 border-[#0A0E27] pl-4 py-2 bg-slate-50">
                        "Initial neural processing suggests a ${scenario.risk.category.toLowerCase()} threat profile. Integrated sensors detect ${scenario.cyber.anomalies} cyber anomalies and ${scenario.camera.status === 'normal' ? 'nominal' : 'concerning'} behavioral patterns in the physical sector."
                     </p>
                     <p className="text-[11px] font-bold opacity-70 uppercase tracking-widest">Verdict: {scenario.alert.explainability}</p>
                  </div>
               </div>
            </section>

            {/* Intelligence Matrix */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
               {/* Physical Intelligence */}
               <section className="space-y-4">
                  <h3 className="font-orbitron font-black text-md uppercase border-b-2 border-[#0A0E27] pb-1">Sector A: Physical Intelligence</h3>
                  <div className="space-y-3">
                     <div className="flex justify-between text-xs border-b border-dashed border-gray-300 pb-1">
                        <span className="font-bold opacity-60">CCTV FEED STATUS:</span>
                        <span className="font-black uppercase">{scenario.camera.status}</span>
                     </div>
                     <div className="flex justify-between text-xs border-b border-dashed border-gray-300 pb-1">
                        <span className="font-bold opacity-60">BEHAVIORAL ANALYSIS:</span>
                        <span className="font-black uppercase">{scenario.camera.behaviour}</span>
                     </div>
                     <div className="flex justify-between text-xs border-b border-dashed border-gray-300 pb-1">
                        <span className="font-bold opacity-60">NEURAL CONFIDENCE:</span>
                        <span className="font-black uppercase">{scenario.camera.confidence}%</span>
                     </div>
                     <div className="flex justify-between text-xs border-b border-dashed border-gray-300 pb-1">
                        <span className="font-bold opacity-60">WEAPONRY SCAN:</span>
                        <span className="font-black uppercase text-[#FF3366]">{scenario.camera.behaviour.includes('WEAPON') ? 'POSITIVE' : 'NEGATIVE'}</span>
                     </div>
                  </div>
               </section>

               {/* Cyber Intelligence */}
               <section className="space-y-4">
                  <h3 className="font-orbitron font-black text-md uppercase border-b-2 border-[#0A0E27] pb-1">Sector B: Cyber Intelligence</h3>
                  <div className="space-y-3">
                     <div className="flex justify-between text-xs border-b border-dashed border-gray-300 pb-1">
                        <span className="font-bold opacity-60">ANOMALY COUNT:</span>
                        <span className="font-black uppercase">{scenario.cyber.anomalies}</span>
                     </div>
                     <div className="flex justify-between text-xs border-b border-dashed border-gray-300 pb-1">
                        <span className="font-bold opacity-60">NETWORK INTEGRITY:</span>
                        <span className="font-black uppercase">{scenario.cyber.status === 'normal' ? 'STABLE' : 'COMPROMISED'}</span>
                     </div>
                  </div>
               </section>
            </div>

            {/* Authorized Signatures */}
            <div className="pt-20 grid grid-cols-2 gap-20">
               <div className="border-t border-[#0A0E27] pt-4">
                  <p className="text-[9px] font-orbitron font-bold uppercase opacity-60 mb-8 text-center">System Operator Authorization</p>
                  <div className="flex flex-col items-center">
                     <span className="font-rajdhani font-black text-lg italic underline-offset-4 underline">{operatorId}</span>
                     <span className="text-[8px] font-mono mt-2 opacity-40">DIGITALLY SIGNED // {new Date().toISOString()}</span>
                  </div>
               </div>
               <div className="border-t border-[#0A0E27] pt-4">
                  <p className="text-[9px] font-orbitron font-bold uppercase opacity-60 mb-8 text-center">Commanding Officer Review</p>
                  <div className="h-10"></div>
                  <div className="w-full h-px bg-gray-200"></div>
                  <p className="text-[10px] font-bold text-center mt-2 opacity-30 italic">Signature Required</p>
               </div>
            </div>
          </div>
        ) : (
          /* Dispatch Center Content */
          <div className="p-8 md:p-16 flex-1 space-y-12 font-rajdhani bg-gray-50">
            <div className="space-y-4">
               <h2 className="font-orbitron font-black text-2xl uppercase text-[#FF3366] flex items-center gap-3">
                 <i className="fa-solid fa-satellite-dish"></i> EMERGENCY DISPATCH CENTER
               </h2>
               <p className="text-sm font-bold opacity-70 uppercase tracking-widest border-b border-gray-200 pb-4">
                 Select a protocol below to notify authorities, rescue teams, or guardians.
               </p>
            </div>

            <div className="grid grid-cols-1 gap-8">
               {/* SMS/WhatsApp Protocol */}
               <div className="bg-white border-l-8 border-[#25D366] p-6 shadow-md rounded-r-lg space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="font-orbitron font-black text-sm uppercase text-[#25D366]">Protocol A: Rapid SMS / WhatsApp Alert</h3>
                    <button onClick={() => copyToClipboard(smsTemplate)} className="text-[10px] font-orbitron font-bold bg-[#25D366]/10 text-[#25D366] px-3 py-1 rounded-full hover:bg-[#25D366] hover:text-white transition-all">COPY TO CLIPBOARD</button>
                  </div>
                  <div className="bg-gray-100 p-4 rounded font-mono text-xs leading-relaxed border border-gray-200 whitespace-pre-wrap">
                    {smsTemplate}
                  </div>
               </div>

               {/* Email Protocol */}
               <div className="bg-white border-l-8 border-[#0A0E27] p-6 shadow-md rounded-r-lg space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="font-orbitron font-black text-sm uppercase text-[#0A0E27]">Protocol B: Official Intelligence Dispatch (Email)</h3>
                    <button onClick={() => copyToClipboard(emailTemplate)} className="text-[10px] font-orbitron font-bold bg-[#0A0E27]/10 text-[#0A0E27] px-3 py-1 rounded-full hover:bg-[#0A0E27] hover:text-white transition-all">COPY TO CLIPBOARD</button>
                  </div>
                  <div className="bg-gray-100 p-4 rounded font-mono text-xs leading-relaxed border border-gray-200 whitespace-pre-wrap h-48 overflow-y-auto">
                    {emailTemplate}
                  </div>
               </div>

               {/* Guardian Panic Protocol */}
               <div className="bg-white border-l-8 border-[#FF3366] p-6 shadow-md rounded-r-lg space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="font-orbitron font-black text-sm uppercase text-[#FF3366]">Protocol C: Guardian / Family Panic Signal</h3>
                    <button onClick={() => copyToClipboard(guardianTemplate)} className="text-[10px] font-orbitron font-bold bg-[#FF3366]/10 text-[#FF3366] px-3 py-1 rounded-full hover:bg-[#FF3366] hover:text-white transition-all">COPY TO CLIPBOARD</button>
                  </div>
                  <div className="bg-[#FF3366]/5 p-4 rounded font-rajdhani font-black text-sm text-[#FF3366] leading-relaxed border border-[#FF3366]/20">
                    "{guardianTemplate}"
                  </div>
               </div>
            </div>

            <div className="pt-6 border-t border-gray-200">
               <p className="text-[10px] font-orbitron font-bold text-center opacity-40 uppercase tracking-[0.4em]">
                 All dispatches are logged with KVC Reference: {reportId}
               </p>
            </div>
          </div>
        )}

        {/* Action Footer */}
        <div className="p-8 bg-[#0D1432] flex flex-col md:flex-row gap-4 items-center justify-between no-print">
           <p className="text-white/40 font-orbitron text-[9px] font-bold uppercase tracking-widest">
              Generated by KAVACH Forensics Engine v4.2
           </p>
           <div className="flex gap-4">
              <button 
                onClick={onClose}
                className="px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl font-orbitron font-bold text-xs uppercase tracking-widest transition-all"
              >
                Cancel
              </button>
              <button 
                onClick={handlePrint}
                className="px-8 py-3 bg-[#00D9FF] hover:bg-white text-[#0A0E27] rounded-xl font-orbitron font-black text-xs uppercase tracking-widest transition-all shadow-[0_0_30px_rgba(0,217,255,0.4)]"
              >
                PRINT / DOWNLOAD PDF
              </button>
           </div>
        </div>

      </div>

      <style>{`
        @media print {
          .no-print { display: none !important; }
          body { background: white !important; }
          .fixed { position: static !important; }
          .p-12 { padding: 0 !important; }
          .rounded-sm { border-radius: 0 !important; }
        }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
      `}</style>
    </div>
  );
};

export default ForensicReport;


import React, { useState } from 'react';

interface EntryScreenProps {
  onEnter: (operatorId?: string) => void;
}

const EntryScreen: React.FC<EntryScreenProps> = ({ onEnter }) => {
  const [isLoading, setIsLoading] = useState(false);

  const handleEnter = () => {
    setIsLoading(true);
    // Simulate biometric handshake
    setTimeout(() => {
      onEnter('COMMANDER');
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-[200] bg-[#0A0E27] flex flex-col items-center justify-center overflow-hidden">
      {/* Dynamic Background Elements */}
      <div className="absolute inset-0 bg-grid opacity-20 pointer-events-none"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,217,255,0.08)_0%,transparent_70%)]"></div>
      
      {/* Laser Scanning Line (Global) */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-30">
        <div className="w-full h-[1px] bg-[var(--primary)] shadow-[0_0_15px_var(--primary)] animate-[scan_5s_linear_infinite]"></div>
      </div>

      <div className="relative flex flex-col items-center text-center px-6 w-full max-w-lg z-10">
        
        {/* Top Identity Section */}
        <div className="mb-10 animate-[fadeIn_0.8s_ease-out]">
          <h1 className="font-orbitron font-black text-6xl md:text-7xl tracking-[-0.05em] uppercase text-glow-cyan bg-gradient-to-r from-[var(--primary)] via-white to-[var(--secondary)] bg-clip-text text-transparent leading-none">
            KAVACH
          </h1>
          <p className="font-rajdhani font-bold text-base md:text-lg text-[var(--primary)] tracking-[0.2em] uppercase opacity-80 mt-2">
            One shield. Two worlds. Total security.
          </p>
        </div>

        {/* Biometric Round Button Section */}
        <div className="relative flex flex-col items-center group">
          {/* Main Round Scanner Button - Shrunken slightly as requested */}
          <button 
            onClick={handleEnter}
            disabled={isLoading}
            className={`relative w-44 h-44 rounded-full border-2 transition-all duration-700 flex flex-col items-center justify-center overflow-hidden shadow-[0_0_50px_rgba(0,0,0,0.5)] active:scale-95 ${
              isLoading 
                ? 'border-[var(--primary)] bg-[var(--primary)]/20 shadow-[0_0_60px_var(--primary)]' 
                : 'border-[var(--primary)]/40 bg-white/5 hover:border-[var(--primary)] hover:bg-[var(--primary)]/10 hover:shadow-[0_0_40px_rgba(0,217,255,0.3)]'
            }`}
          >
            {/* Interior Scanning Animation */}
            <div className={`absolute inset-0 bg-gradient-to-t from-transparent via-[var(--primary)]/20 to-transparent w-full h-1/2 -top-1/2 ${isLoading ? 'animate-[biometricScan_1s_ease-in-out_infinite]' : 'group-hover:animate-[biometricScan_2s_ease-in-out_infinite]'}`}></div>
            
            {/* Icon & Integrated Text */}
            <div className="relative z-10 flex flex-col items-center gap-3">
              {isLoading ? (
                <i className="fa-solid fa-dna text-4xl text-white animate-pulse"></i>
              ) : (
                <i className="fa-solid fa-fingerprint text-5xl text-[var(--primary)] group-hover:text-white transition-colors duration-500"></i>
              )}
              
              <span className={`font-orbitron font-black text-[10px] tracking-[0.3em] transition-all duration-500 uppercase ${
                isLoading ? 'text-white animate-pulse' : 'text-[var(--primary)] group-hover:text-white'
              }`}>
                {isLoading ? 'SYNCING...' : 'ENTER KAVACH'}
              </span>
            </div>

            {/* Loading Ring */}
            {isLoading && (
              <svg className="absolute inset-0 w-full h-full -rotate-90">
                <circle
                  cx="88" cy="88" r="82"
                  fill="transparent"
                  stroke="var(--primary)"
                  strokeWidth="3"
                  strokeDasharray="515"
                  className="animate-[progressDraw_1.2s_ease-out_forwards]"
                />
              </svg>
            )}
          </button>

          {/* Subtext Below Circle */}
          <div className="mt-8 flex flex-col items-center gap-2">
             <div className="flex items-center gap-2">
               <div className={`h-[1px] bg-[var(--primary)]/30 transition-all duration-700 ${isLoading ? 'w-32' : 'w-12 group-hover:w-24'}`}></div>
             </div>
             <p className="text-[9px] font-rajdhani font-bold text-[#94A3C2] tracking-[0.3em] uppercase opacity-40">
               {isLoading ? 'Neural Validation in Progress' : 'Biometric Handshake Required'}
             </p>
          </div>
        </div>
      </div>

      {/* Security Metadata Footer */}
      <div className="absolute bottom-8 left-0 right-0 px-10 flex justify-between items-end opacity-20 pointer-events-none">
        <div className="flex flex-col">
          <span className="text-[8px] font-orbitron font-bold text-white uppercase tracking-widest">Protocol</span>
          <span className="text-[10px] font-mono text-[var(--primary)]">KVC-ALPHA-9</span>
        </div>
        <div className="flex flex-col items-end">
          <span className="text-[8px] font-orbitron font-bold text-white uppercase tracking-widest">Status</span>
          <span className="text-[10px] font-mono text-[var(--secondary)]">STANDBY_MODE</span>
        </div>
      </div>

      <style>{`
        @keyframes scan { 
          0% { transform: translateY(-100vh); } 
          100% { transform: translateY(100vh); } 
        }
        @keyframes biometricScan {
          0% { top: -50%; }
          100% { top: 100%; }
        }
        @keyframes progressDraw {
          from { stroke-dashoffset: 515; }
          to { stroke-dashoffset: 0; }
        }
        @keyframes fadeIn { 
          from { opacity: 0; transform: translateY(15px); } 
          to { opacity: 1; transform: translateY(0); } 
        }
      `}</style>
    </div>
  );
};

export default EntryScreen;

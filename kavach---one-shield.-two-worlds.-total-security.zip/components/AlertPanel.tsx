
import React from 'react';
import { AlertData, AlertReason } from '../types';

interface AlertPanelProps {
  data: AlertData;
  onDismiss?: () => void;
}

const AlertPanel: React.FC<AlertPanelProps> = ({ data, onDismiss }) => {
  const isHighSeverity = data.severity === 'high';

  return (
    <div className="panel-blur border-cyan-glow rounded-3xl p-6 lg:p-8 transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_0_50px_rgba(0,217,255,0.15)] flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-[#00D9FF]/10 flex items-center justify-center text-[#00D9FF]">
            <i className="fa-solid fa-bell text-xl"></i>
          </div>
          <h2 className="font-orbitron font-bold text-lg tracking-widest text-[#00D9FF] uppercase">Security Alerts & Details</h2>
        </div>
        {data.actionRequired && onDismiss && (
          <button 
            onClick={onDismiss}
            className="px-3 py-1 bg-white/5 hover:bg-[#00FF88]/20 border border-white/10 hover:border-[#00FF88]/50 rounded text-[9px] font-orbitron font-bold text-white/50 hover:text-[#00FF88] transition-all"
          >
            ACKNOWLEDGE & RESET
          </button>
        )}
      </div>

      <div className={`p-6 rounded-2xl border mb-6 transition-all duration-500 flex items-start gap-4 ${
          isHighSeverity ? 'bg-[#FF3366]/10 border-[#FF3366]/40 animate-shake' : 'bg-[#00FF88]/10 border-[#00FF88]/40'
      }`}>
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${
            isHighSeverity ? 'bg-[#FF3366]/20 text-[#FF3366]' : 'bg-[#00FF88]/20 text-[#00FF88]'
        }`}>
            <i className={`fa-solid ${isHighSeverity ? 'fa-triangle-exclamation' : 'fa-shield-halved'} text-2xl`}></i>
        </div>
        <div>
            <h3 className={`font-orbitron font-black text-xl mb-1 tracking-tight ${isHighSeverity ? 'text-[#FF3366]' : 'text-[#00FF88]'}`}>
                {data.title}
            </h3>
            <p className="font-rajdhani text-sm font-bold text-[#94A3C2] uppercase tracking-wider">{data.subtitle}</p>
        </div>
      </div>

      <div className="space-y-4 flex-1">
        <h4 className="font-orbitron text-[10px] font-bold uppercase tracking-[0.2em] text-[#94A3C2]">Threat Analysis:</h4>
        <ul className="space-y-3">
            {data.reasons.map((reason, idx) => {
                const isObj = typeof reason === 'object';
                const type = isObj ? (reason as AlertReason).type : 'info';
                const text = isObj ? (reason as AlertReason).text : reason as string;

                let colorClass = 'border-white/10 bg-white/5 text-[#94A3C2]';
                let iconClass = 'fa-circle-info';
                
                if (type === 'danger' || isHighSeverity) {
                    colorClass = 'border-[#FF3366]/30 bg-[#FF3366]/5 text-[#FF3366]';
                    iconClass = 'fa-triangle-exclamation';
                } else if (type === 'warning') {
                    colorClass = 'border-[#FFB800]/30 bg-[#FFB800]/5 text-[#FFB800]';
                    iconClass = 'fa-exclamation-circle';
                } else {
                    colorClass = 'border-[#00FF88]/30 bg-[#00FF88]/5 text-[#00FF88]';
                    iconClass = 'fa-check-circle';
                }

                return (
                    <li key={idx} className={`p-3 rounded-lg border text-xs font-rajdhani font-bold flex items-center gap-3 transition-all duration-300 ${colorClass}`}>
                        <i className={`fa-solid ${iconClass}`}></i>
                        {text}
                    </li>
                );
            })}
        </ul>

        <div className="mt-4 p-4 rounded-xl border border-[#00D9FF]/20 bg-[#00D9FF]/5">
          <h4 className="font-orbitron text-[9px] font-bold uppercase tracking-[0.2em] text-[#00D9FF] mb-2 flex items-center gap-2">
            <i className="fa-solid fa-clipboard-check"></i>
            Recommended Operator Action:
          </h4>
          <p className="font-rajdhani text-sm font-bold text-white leading-relaxed">
            {data.recommendedAction}
          </p>
        </div>
      </div>

      <div className="mt-6 pt-4 border-t border-white/5">
        <p className="font-orbitron text-[9px] uppercase tracking-widest text-[#94A3C2] mb-1">Risk Explainability:</p>
        <p className={`font-rajdhani text-xs font-bold ${isHighSeverity ? 'text-[#FF3366]' : 'text-[#00FF88]'}`}>
          {data.explainability}
        </p>
      </div>

      {data.actionRequired && (
          <div className="mt-6 bg-[#FF3366] text-white p-3 rounded-xl font-orbitron font-black text-center tracking-widest text-sm animate-pulse shadow-[0_0_20px_rgba(255,51,102,0.5)] cursor-pointer" onClick={onDismiss}>
              ⚠️ IMMEDIATE ACTION REQUIRED (CLICK TO DISMISS)
          </div>
      )}
    </div>
  );
};

export default AlertPanel;


import React, { useEffect, useState } from 'react';
import { RiskData } from '../types';

interface RiskGaugeProps {
  data: RiskData;
}

const RiskGauge: React.FC<RiskGaugeProps> = ({ data }) => {
  const [displayScore, setDisplayScore] = useState(0);
  const size = 220;
  const strokeWidth = 10;
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (displayScore / 100) * circumference;

  useEffect(() => {
    let start = displayScore;
    const end = data.score;
    const duration = 1000;
    const startTime = performance.now();

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const current = Math.floor(start + (end - start) * progress);
      setDisplayScore(current);

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [data.score]);

  const MiniBar = ({ label, score, color }: { label: string, score: number, color: string }) => (
    <div className="w-full">
      <div className="flex justify-between items-end mb-1 px-1">
        <span className="font-orbitron text-[8px] uppercase tracking-widest text-[#94A3C2]">{label}</span>
        <span className="font-orbitron text-[10px] font-bold" style={{ color }}>{score}%</span>
      </div>
      <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden border border-white/5">
        <div 
          className="h-full transition-all duration-1000" 
          style={{ width: `${score}%`, backgroundColor: color, boxShadow: `0 0 10px ${color}80` }}
        ></div>
      </div>
    </div>
  );

  return (
    <div className="panel-blur border-cyan-glow rounded-3xl p-6 lg:p-8 transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_0_50px_rgba(0,217,255,0.15)] flex flex-col items-center">
      <div className="w-full flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-lg bg-[#00D9FF]/10 flex items-center justify-center text-[#00D9FF]">
          <i className="fa-solid fa-triangle-exclamation text-xl"></i>
        </div>
        <h2 className="font-orbitron font-bold text-lg tracking-widest text-[#00D9FF] uppercase">Integrated Risk Analysis</h2>
      </div>

      <div className="flex flex-col lg:flex-row items-center gap-8 w-full justify-center">
        <div className="relative flex items-center justify-center">
          <svg width={size} height={size} className="transform -rotate-90">
            <circle
              cx={size / 2}
              cy={size / 2}
              r={radius}
              fill="transparent"
              stroke="rgba(255,255,255,0.05)"
              strokeWidth={strokeWidth}
            />
            <circle
              cx={size / 2}
              cy={size / 2}
              r={radius}
              fill="transparent"
              stroke={data.color}
              strokeWidth={strokeWidth}
              strokeDasharray={circumference}
              style={{ 
                  strokeDashoffset: offset,
                  transition: 'stroke 0.5s ease, stroke-dashoffset 0.1s linear'
              }}
              strokeLinecap="round"
            />
          </svg>

          <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
            <div className="flex items-baseline gap-1">
              <span className="font-orbitron text-5xl font-black text-glow-cyan leading-none">
                {displayScore}
              </span>
              <span className="font-orbitron text-lg font-bold text-[#94A3C2]/40">/100</span>
            </div>
            <span className="font-orbitron text-[8px] tracking-[0.3em] uppercase text-[#94A3C2] font-bold mt-2">
              Risk Score (0-100 Scale)
            </span>
          </div>
        </div>

        <div className="w-full lg:w-56 space-y-6">
          <MiniBar label="Current Physical Risk" score={data.physicalScore} color="#00D9FF" />
          <MiniBar label="Current Cyber Risk" score={data.cyberScore} color="#FFB800" />
          
          <div className="pt-2">
            <p className="font-orbitron text-[8px] text-[#94A3C2]/60 uppercase tracking-widest text-center mb-2">Scale: 0 (Safe) to 100 (Critical)</p>
            <div className={`px-4 py-2 rounded-lg font-orbitron font-black text-[10px] tracking-[0.2em] border text-center transition-all duration-500 ${
                data.score > 60 
                  ? 'bg-[#FF3366]/20 border-[#FF3366] text-[#FF3366] animate-pulse' 
                  : data.score > 30 
                    ? 'bg-[#FFB800]/20 border-[#FFB800] text-[#FFB800]' 
                    : 'bg-[#00FF88]/20 border-[#00FF88] text-[#00FF88]'
            }`}>
              {data.category} THREAT LEVEL
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RiskGauge;

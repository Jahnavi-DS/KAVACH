
import React, { useState, useEffect, useRef } from 'react';
import { CameraData, CameraMode } from '../types';

interface CameraPanelProps {
  data: CameraData;
  isAnalyzing?: boolean;
  isConnecting?: boolean;
  isUserFacing?: boolean;
  isRecording?: boolean;
}

const CameraPanel: React.FC<CameraPanelProps> = ({ data, isAnalyzing, isConnecting, isUserFacing = true, isRecording = false }) => {
  const [isTacticalView, setIsTacticalView] = useState(false);
  const [cameraMode, setCameraMode] = useState<CameraMode>('LIVE');
  const [playbackTime, setPlaybackTime] = useState(120); // minutes ago
  const [coordinates, setCoordinates] = useState({ lat: 28.6139, lng: 77.2090 });
  const videoRef = useRef<HTMLVideoElement>(null);
  const tacticalVideoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setCoordinates(prev => ({
        lat: prev.lat + (Math.random() - 0.5) * 0.0001,
        lng: prev.lng + (Math.random() - 0.5) * 0.0001
      }));
    }, 2000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (videoRef.current && data.stream) {
      videoRef.current.srcObject = data.stream;
    }
  }, [data.stream]);

  useEffect(() => {
    if (tacticalVideoRef.current && isTacticalView && data.stream) {
      tacticalVideoRef.current.srcObject = data.stream;
    }
  }, [isTacticalView, data.stream]);

  const getThreatVerdict = () => {
    if (isAnalyzing) return { 
      status: 'PROCESSING...', 
      text: 'Neural engines are performing deep forensic analysis (30s threshold)... Scanning biometric hashes and skeletal posture markers.', 
      color: 'text-white/50 bg-white/5 border-white/10',
      hazardLevel: 'CALCULATING',
      objects: 'SCANNING...'
    };
    
    if (data.status === 'normal') {
      return {
        status: 'THREAT ASSESSMENT: SECURE',
        text: 'NO HARMFUL OBJECTS DETECTED. LIVE FEED IS VERIFIED AS SAFE. Personnel movements align with 72-hour baseline nominal flow.',
        color: 'text-[#00FF88] bg-[#00FF88]/10 border-[#00FF88]/30',
        hazardLevel: '0.01%',
        objects: 'NONE DETECTED',
        indicator: 'fa-circle-check'
      };
    } else {
      const isLethal = data.behaviour.toLowerCase().includes('weapon') || data.behaviour.toLowerCase().includes('gun');
      
      if (isLethal) {
        return {
          status: 'THREAT ASSESSMENT: LETHAL BREACH',
          text: 'CRITICAL ALERT: Visual and Thermal sensors have identified a high-density metallic profile consistent with a 7.62mm firearm. Movement suggests rapid-deployment training. Target has entered restricted Zone-Alpha without biometric handshake.',
          color: 'text-[#FF3366] bg-[#FF3366]/10 border-[#FF3366]/30',
          hazardLevel: '98.7%',
          objects: 'LETHAL WEAPON SIGNATURE (7.62mm AK-VAR)',
          indicator: 'fa-skull-crossbones'
        };
      } else {
        return {
          status: 'THREAT ASSESSMENT: SUSPICIOUS RECON',
          text: 'ANOMALY DETECTED: Individual displaying high-frequency facial occlusion and erratic loitering near restricted portal. Skeletal tracking indicates non-standard concealment patterns (concealed mass detected in abdominal region). Multi-spectral sensors report irregular IR spikes.',
          color: 'text-[#FFB800] bg-[#FFB800]/10 border-[#FFB800]/30',
          hazardLevel: '64.2%',
          objects: 'UNACCOUNTED HIGH-DENSITY OBJECT',
          indicator: 'fa-triangle-exclamation'
        };
      }
    }
  };

  const getIntelligenceSummary = () => {
    if (isAnalyzing) {
      return [
        { icon: 'fa-spinner fa-spin', text: 'SYNCING NEURAL ENGINE...', color: 'text-[#94A3C2]' },
        { icon: 'fa-microchip', text: 'SCANNING RF SIGNATURES...', color: 'text-[#94A3C2]' },
        { icon: 'fa-dna', text: 'VERIFYING BIOMETRIC HASH...', color: 'text-[#94A3C2]' }
      ];
    }

    if (cameraMode === 'DVR') {
      return [
        { icon: 'fa-clock-rotate-left', text: 'MODE: TACTICAL PLAYBACK', color: 'text-[#FFB800]' },
        { icon: 'fa-database', text: 'STORAGE: NODE-ALPHA-REC', color: 'text-[#FFB800]' },
        { icon: 'fa-calendar-day', text: `TIME: -${playbackTime} MINS`, color: 'text-[#FFB800]' },
        { icon: 'fa-magnifying-glass', text: 'QUERYING HISTORICAL SIGS', color: 'text-[#FFB800]' }
      ];
    }

    if (data.status === 'normal') {
      return [
        { icon: 'fa-shield-check', text: 'ENV: SECURE (100% INTEGRITY)', color: 'text-[var(--secondary)]' },
        { icon: 'fa-gun', text: 'WEAPONRY: NO LETHAL SIGS', color: 'text-[var(--secondary)]' },
        { icon: 'fa-temperature-half', text: 'THERMAL: STABLE (36.5°C AVG)', color: 'text-[var(--secondary)]' },
        { icon: 'fa-user-check', text: 'ID: VERIFIED PERSONNEL (99%)', color: 'text-[var(--secondary)]' },
        { icon: 'fa-person-walking', text: 'MOTION: PREDICTIVE/NOMINAL', color: 'text-[var(--secondary)]' },
        { icon: 'fa-ear-listen', text: 'ACOUSTIC: AMBIENT (42dB)', color: 'text-[var(--secondary)]' },
        { icon: 'fa-box-open', text: 'ASSETS: 04 DETECTED/AUTH', color: 'text-[var(--secondary)]' },
        { icon: 'fa-radiation', text: 'CBRN: ZERO THRESHOLD', color: 'text-[var(--secondary)]' }
      ];
    } else {
      const isWeaponDetected = data.behaviour.toLowerCase().includes('weapon') || data.behaviour.toLowerCase().includes('gun');
      return [
        { icon: 'fa-triangle-exclamation', text: 'ENV: CRITICAL BREACH RISK', color: 'text-[#FF3366]' },
        { 
          icon: isWeaponDetected ? 'fa-gun' : 'fa-magnifying-glass-chart', 
          text: isWeaponDetected ? 'WEAPONRY: LETHAL DETECTED' : 'SIG: UNKNOWN ANOMALY', 
          color: isWeaponDetected ? 'text-[#FF3366]' : 'text-[#FFB800]' 
        },
        { icon: 'fa-fire', text: 'THERMAL: IRREGULAR HEAT SPIKES', color: 'text-[#FF3366]' },
        { icon: 'fa-user-secret', text: 'ID: UNKNOWN/BLACK-LISTED', color: 'text-[#FF3366]' },
        { icon: 'fa-route', text: 'MOTION: ERRATIC LOITERING', color: 'text-[#FFB800]' },
        { icon: 'fa-volume-high', text: 'ACOUSTIC: STRESS FREQ DETECTED', color: 'text-[#FF3366]' },
        { icon: 'fa-cubes-stacked', text: 'ASSETS: UNACCOUNTED OBJECTS', color: 'text-[#FFB800]' },
        { icon: 'fa-network-wired', text: 'RF: UNAUTHORIZED UPLINK', color: 'text-[#FF3366]' }
      ];
    }
  };

  const getLiveMetadata = () => [
    { label: 'Signal', value: '98.2% (SAT-VII)', icon: 'fa-wifi' },
    { label: 'Latency', value: '42ms (EDGE AI)', icon: 'fa-bolt' },
    { label: 'Security', value: 'Q-AES-512', icon: 'fa-lock' },
    { label: 'Bitrate', value: '12.4 Mbps (HDR)', icon: 'fa-chart-line' },
    { label: 'Frame', value: '60 FPS (TACTICAL)', icon: 'fa-image' },
    { label: 'Sync', value: 'NEURAL LINK ACTIVE', icon: 'fa-brain' }
  ];

  const renderVideoOverlay = (isFull: boolean) => (
    <>
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-20">
        <div className="w-full h-[2px] bg-[var(--primary)] shadow-[0_0_15px_var(--primary)] opacity-20 animate-[scan_4s_linear_infinite]"></div>
      </div>
      
      {/* Coordinates: Moved to top-right to avoid "middle" */}
      <div className="absolute top-3 right-3 flex items-center gap-2 md:gap-4 px-3 py-1 bg-black/70 backdrop-blur-md rounded-full border border-white/10 z-30 shadow-2xl">
        <div className="flex flex-col items-center">
          <span className="text-[6px] md:text-[8px] text-[#94A3C2] font-orbitron font-bold uppercase tracking-widest">Lat</span>
          <span className="text-[9px] md:text-[11px] text-[var(--primary)] font-mono font-bold">{coordinates.lat.toFixed(4)}°</span>
        </div>
        <div className="w-px h-3 bg-white/20"></div>
        <div className="flex flex-col items-center">
          <span className="text-[6px] md:text-[8px] text-[#94A3C2] font-orbitron font-bold uppercase tracking-widest">Lng</span>
          <span className="text-[9px] md:text-[11px] text-[var(--primary)] font-mono font-bold">{coordinates.lng.toFixed(4)}°</span>
        </div>
      </div>

      {/* REC Indicator: Moved to bottom-left side, above timeline */}
      {isRecording && (
        <div className={`absolute ${cameraMode === 'DVR' ? 'bottom-20' : 'bottom-4'} left-3 flex items-center gap-2 bg-black/50 backdrop-blur-md border border-[#FF3366]/40 px-3 py-1.5 rounded-md z-40 transition-all duration-500`}>
           <div className="w-2.5 h-2.5 rounded-full bg-[#FF3366] animate-pulse"></div>
           <span className="font-orbitron font-black text-[9px] text-[#FF3366] uppercase tracking-widest leading-none">REC ACTIVE</span>
        </div>
      )}

      {/* DVR Playback Status: Moved to bottom-right side, above timeline */}
      {cameraMode === 'DVR' && (
        <div className="absolute inset-0 bg-black/30 pointer-events-none border-4 border-[#FFB800]/20 z-10">
            <div className="absolute bottom-20 right-3 flex flex-col items-end gap-1.5 pointer-events-auto">
               <div className="bg-[#FFB800] text-black px-4 py-1.5 font-orbitron font-black text-[10px] tracking-widest rounded-lg animate-pulse flex items-center gap-2 shadow-lg">
                   <i className="fa-solid fa-play"></i> DVR PLAYBACK
               </div>
               <div className="text-[#FFB800] font-mono text-[10px] bg-black/80 px-2 py-1 rounded border border-[#FFB800]/30 shadow-md">
                  STAMP: {new Date(Date.now() - playbackTime * 60000).toLocaleTimeString()}
               </div>
            </div>
        </div>
      )}

      {isFull && (
        <div className="absolute top-10 left-4 md:left-10 p-2 md:p-4 border-l-2 border-t-2 border-[var(--primary)] text-[var(--primary)] font-orbitron text-[8px] md:text-xs z-30 bg-black/60 backdrop-blur-sm shadow-xl">
          SYSTEM: KAVACH-ALPHA<br/>
          SENSORS: MULTI-SPECTRAL IR<br/>
          OBJECT_IDS: ACTIVE<br/>
          THREAT_COEFF: {data.confidence / 100}
        </div>
      )}
    </>
  );

  const verdict = getThreatVerdict();

  return (
    <>
      <div className="panel-blur rounded-3xl p-5 md:p-8 transition-all duration-500 hover:border-[var(--primary)]/30 group">
        <div className="flex items-center justify-between mb-4 md:mb-6">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-lg ${data.isLive ? 'bg-[#FF3366]/10 text-[#FF3366]' : 'bg-[var(--primary)]/10 text-[var(--primary)]'} flex items-center justify-center shrink-0 border border-white/5`}>
              <i className={`fa-solid ${data.isLive ? 'fa-tower-broadcast' : 'fa-video-camera'} text-lg`}></i>
            </div>
            <div className="flex flex-col">
              <h2 className={`font-orbitron font-bold text-sm md:text-lg tracking-widest ${data.isLive ? 'text-[#FF3366]' : 'text-[var(--primary)]'} uppercase leading-none`}>
                {cameraMode === 'LIVE' ? 'Live Deployment Feed' : 'CCTV Tactical Archive'}
              </h2>
              <span className="text-[8px] font-mono text-[#94A3C2] uppercase tracking-[0.2em] mt-1">Uplink: {cameraMode === 'LIVE' ? 'Synchronized' : 'Buffered Archive'}</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button 
                onClick={() => setCameraMode(prev => prev === 'LIVE' ? 'DVR' : 'LIVE')}
                className={`w-9 h-9 md:w-10 md:h-10 rounded-lg border transition-all flex items-center justify-center shadow-lg ${
                    cameraMode === 'DVR' 
                    ? 'bg-[#FFB800] border-[#FFB800] text-black scale-110' 
                    : 'bg-white/5 border-white/10 text-white/50 hover:bg-white/10'
                }`}
                title="Toggle DVR Mode"
            >
                <i className={`fa-solid ${cameraMode === 'LIVE' ? 'fa-clock-rotate-left' : 'fa-satellite-dish'}`}></i>
            </button>
            <button 
                onClick={() => setIsTacticalView(true)}
                className="w-9 h-9 md:w-10 md:h-10 rounded-lg bg-white/5 hover:bg-[var(--primary)]/20 border border-white/10 flex items-center justify-center text-white/50 hover:text-[var(--primary)] transition-all shrink-0"
            >
                <i className="fa-solid fa-expand-arrows-alt"></i>
            </button>
          </div>
        </div>

        <div className="relative w-full aspect-video bg-black rounded-2xl overflow-hidden border border-white/10 group-hover:border-[var(--primary)]/40 transition-all shadow-2xl">
          {data.stream ? (
            <video 
              ref={videoRef}
              autoPlay 
              playsInline 
              muted 
              className={`w-full h-full object-cover ${cameraMode === 'DVR' ? 'brightness-50 sepia-[0.3]' : ''}`}
              style={{ transform: isUserFacing ? 'scaleX(-1)' : 'none' }}
            />
          ) : (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#05081a]">
               <i className="fa-solid fa-satellite-dish text-white/5 text-4xl mb-3 animate-pulse"></i>
               <span className="text-white/10 font-orbitron text-[10px] tracking-[0.6em] uppercase">Wait for Uplink</span>
            </div>
          )}
          {renderVideoOverlay(false)}

          {cameraMode === 'DVR' && (
            <div className="absolute bottom-0 left-0 right-0 p-4 bg-black/80 backdrop-blur-md border-t border-[#FFB800]/30 z-30">
                <div className="flex items-center gap-4">
                    <span className="font-orbitron font-bold text-[8px] text-[#FFB800] uppercase tracking-widest whitespace-nowrap">Timeline (24H)</span>
                    <input 
                        type="range" 
                        min="1" 
                        max="1440" 
                        value={playbackTime} 
                        onChange={(e) => setPlaybackTime(parseInt(e.target.value))}
                        className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer accent-[#FFB800]"
                    />
                    <div className="flex items-center gap-2">
                        <button className="text-[#FFB800] text-[10px] hover:scale-120 transition-transform"><i className="fa-solid fa-backward-step"></i></button>
                        <button className="text-[#FFB800] text-[10px] hover:scale-120 transition-transform"><i className="fa-solid fa-play"></i></button>
                        <button className="text-[#FFB800] text-[10px] hover:scale-120 transition-transform"><i className="fa-solid fa-forward-step"></i></button>
                    </div>
                </div>
            </div>
          )}

          {(isAnalyzing || isConnecting) && (
            <div className="absolute inset-0 z-40 bg-[#0A0E27]/90 backdrop-blur-md flex flex-col items-center justify-center text-center p-4">
              <div className="relative w-14 h-14 mb-4">
                <div className="absolute inset-0 border-2 border-[var(--primary)]/20 rounded-full"></div>
                <div className="absolute inset-0 border-2 border-t-[var(--primary)] rounded-full animate-spin"></div>
              </div>
              <span className="font-orbitron text-[var(--primary)] font-bold text-[10px] tracking-widest uppercase animate-pulse">
                {isConnecting ? 'Initialising Secure Tunnel...' : 'Neural Pattern Processing...'}
              </span>
            </div>
          )}
          
          <div className={`absolute top-4 left-4 flex items-center gap-2 px-3 py-1.5 rounded-full border text-[9px] font-orbitron font-bold uppercase transition-all duration-500 z-20 backdrop-blur-md ${
            isAnalyzing ? 'bg-white/10 border-white/20 text-white/50' :
            data.status === 'suspicious' ? 'bg-[#FF3366]/20 border-[#FF3366] text-[#FF3366] animate-pulse' : 'bg-[var(--secondary)]/20 border-[var(--secondary)] text-[var(--secondary)]'
          }`}>
            <div className={`w-1.5 h-1.5 rounded-full ${data.status === 'suspicious' ? 'bg-[#FF3366]' : 'bg-[var(--secondary)]'} animate-ping`}></div>
            {isAnalyzing ? 'Processing' : (cameraMode === 'DVR' ? 'ARCHIVE DATA' : data.behaviour)}
          </div>
        </div>

        {/* Informative Report Sections */}
        <div className="mt-6 space-y-4">
           {/* Neural Threat Verdict Summary */}
           <div className={`p-4 md:p-6 rounded-2xl border transition-all duration-500 shadow-xl ${verdict.color}`}>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <i className={`fa-solid ${verdict.indicator || 'fa-shield-halved'} text-xl`}></i>
                  <h3 className="font-orbitron font-black text-xs md:text-sm uppercase tracking-widest">{verdict.status}</h3>
                </div>
                <div className="text-right">
                  <span className="text-[7px] font-orbitron uppercase opacity-60 block">AI Hazard Index</span>
                  <span className="text-xs font-mono font-black">{verdict.hazardLevel}</span>
                </div>
              </div>
              <p className="font-rajdhani text-xs font-bold uppercase tracking-wider leading-relaxed border-b border-white/10 pb-3 mb-3">
                {verdict.text}
              </p>
              <div className="grid grid-cols-2 gap-4">
                 <div className="flex flex-col gap-0.5">
                    <span className="text-[7px] font-orbitron uppercase opacity-50">Lethal Object Signature</span>
                    <span className="text-[10px] font-orbitron font-black uppercase text-white truncate">{verdict.objects}</span>
                 </div>
                 <div className="flex flex-col gap-0.5">
                    <span className="text-[7px] font-orbitron uppercase opacity-50">Neural Behavioral Scan</span>
                    <span className="text-[10px] font-orbitron font-black uppercase text-white truncate">
                        {data.status === 'normal' ? 'SAFE: STANDARD MOVEMENT' : 'HARM: HOSTILE INTENT IDENTIFIED'}
                    </span>
                 </div>
              </div>
           </div>

           {/* Intelligence Grid */}
           <div className={`p-4 md:p-5 bg-black/40 rounded-2xl border transition-all duration-500 ${cameraMode === 'DVR' ? 'border-[#FFB800]/30' : 'border-white/5 shadow-inner'}`}>
              <div className="flex items-center gap-2 mb-4 border-b border-white/5 pb-2">
                <i className={`fa-solid ${cameraMode === 'DVR' ? 'fa-clock-rotate-left text-[#FFB800]' : 'fa-shield-virus text-[var(--primary)]'} text-xs`}></i>
                <p className={`text-[10px] font-orbitron font-bold uppercase tracking-[0.2em] ${cameraMode === 'DVR' ? 'text-[#FFB800]' : 'text-[var(--primary)]'}`}>
                    {cameraMode === 'DVR' ? 'Historical Sensor Log' : 'Threat Intelligence Report'}
                </p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-3 gap-x-6">
                {getIntelligenceSummary().map((item, idx) => (
                  <div key={idx} className="flex items-center gap-3 group/item">
                    <div className={`w-7 h-7 rounded bg-white/5 flex items-center justify-center ${item.color} border border-white/5 transition-transform group-hover/item:scale-110`}>
                       <i className={`fa-solid ${item.icon} text-[10px]`}></i>
                    </div>
                    <p className={`font-rajdhani text-[11px] font-bold uppercase tracking-wider ${item.color} leading-none`}>
                      {item.text}
                    </p>
                  </div>
                ))}
              </div>
           </div>

           {/* Telemetry Grid */}
           <div className="p-4 md:p-5 bg-black/40 rounded-2xl border border-white/5 shadow-inner">
              <div className="flex items-center gap-2 mb-4 border-b border-white/5 pb-2">
                <i className="fa-solid fa-microchip text-[#94A3C2] text-xs"></i>
                <p className="text-[10px] font-orbitron font-bold text-[#94A3C2] uppercase tracking-[0.2em]">Live Stream Telemetry</p>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {getLiveMetadata().map((item, idx) => (
                  <div key={idx} className="flex flex-col gap-1 bg-white/5 p-2 rounded-lg border border-white/5 hover:border-[var(--primary)]/20 transition-colors">
                    <div className="flex items-center gap-1.5">
                       <i className={`fa-solid ${item.icon} text-[8px] text-[var(--primary)]/60`}></i>
                       <span className="text-[7px] font-orbitron text-[#94A3C2] uppercase tracking-tighter opacity-70">{item.label}</span>
                    </div>
                    <span className="text-[9px] md:text-[10px] font-orbitron font-black text-white leading-none truncate">{item.value}</span>
                  </div>
                ))}
              </div>
           </div>
        </div>
      </div>

      {isTacticalView && (
        <div className="fixed inset-0 z-[100] bg-[#0A0E27] flex flex-col items-center justify-center p-4 animate-[fadeIn_0.3s_ease-out]">
          <button 
            onClick={() => setIsTacticalView(false)}
            className="absolute top-6 right-6 w-12 h-12 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-center text-white/70 transition-all z-[110] hover:scale-110 active:scale-90"
          >
            <i className="fa-solid fa-xmark text-xl"></i>
          </button>
          <div className="w-full max-w-6xl aspect-video bg-black rounded-3xl border border-[var(--primary)]/40 overflow-hidden relative shadow-[0_0_100px_rgba(0,217,255,0.2)]">
             <div className="relative w-full h-full flex items-center justify-center">
              {data.stream && (
                <video 
                  ref={tacticalVideoRef} 
                  autoPlay 
                  playsInline 
                  muted 
                  className={`w-full h-full object-contain ${cameraMode === 'DVR' ? 'brightness-50 sepia-[0.3]' : ''}`}
                  style={{ transform: isUserFacing ? 'scaleX(-1)' : 'none' }} 
                />
              )}
              {renderVideoOverlay(true)}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default CameraPanel;

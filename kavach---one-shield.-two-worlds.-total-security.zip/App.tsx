
import React, { useState, useEffect, useRef } from 'react';
import Header from './components/Header';
import CameraPanel from './components/CameraPanel';
import CyberLogPanel from './components/CyberLogPanel';
import RiskGauge from './components/RiskGauge';
import AlertPanel from './components/AlertPanel';
import ControlPanel from './components/ControlPanel';
import EntryScreen from './components/EntryScreen';
import SettingsModal, { SystemConfig } from './components/SettingsModal';
import ForensicReport from './components/ForensicReport';
import { NORMAL_SCENARIO, SUSPICIOUS_SCENARIO, THREAT_SCENARIO } from './constants';
import { Scenario, CyberLog } from './types';

const THEMES: Record<string, any> = {
  'STEALTH BLUE': { primary: '#00D9FF', secondary: '#00FF88', glow: 'rgba(0, 217, 255, 0.5)' },
  'CRIMSON ALERT': { primary: '#FF3366', secondary: '#FFB800', glow: 'rgba(255, 51, 102, 0.5)' },
  'NIGHT VISION': { primary: '#00FF88', secondary: '#00D9FF', glow: 'rgba(0, 255, 136, 0.5)' },
  'AMBER TACTICAL': { primary: '#FFB800', secondary: '#FF3366', glow: 'rgba(255, 184, 0, 0.5)' }
};

const MOCK_ACTIONS = ["Port Scan: SSH", "Database Query", "Kernel Sync", "Satellite Handshake", "Credential Verification", "Encrypted Data Packet Transfer", "Firewall Rule Update", "Root Access Attempt"];
const MOCK_USERS = ["officer_12", "admin_user", "officer_07", "security_ops", "unknown_ip", "guest_sys"];

const App: React.FC = () => {
  const [isEntered, setIsEntered] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [operatorId, setOperatorId] = useState('KVC-9842');
  const [activeTheme, setActiveTheme] = useState('STEALTH BLUE');
  const [systemConfig, setSystemConfig] = useState<SystemConfig>({
    autoAnalysis: false,
    highFreqLink: true,
    biometricBypass: false
  });

  const [scenario, setScenario] = useState<Scenario>(NORMAL_SCENARIO);
  const [activeScenarioLabel, setActiveScenarioLabel] = useState<string>('SAFE');
  const [dateTime, setDateTime] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [hasAnalysed, setHasAnalysed] = useState(false);
  const [analysisTimer, setAnalysisTimer] = useState(0);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [isRecording, setIsRecording] = useState(false);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);

  useEffect(() => {
    const theme = THEMES[activeTheme];
    const root = document.documentElement;
    root.style.setProperty('--primary', theme.primary);
    root.style.setProperty('--secondary', theme.secondary);
    root.style.setProperty('--glow', theme.glow);
  }, [activeTheme]);

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      const dateStr = now.toLocaleDateString('en-GB');
      const timeStr = now.toLocaleTimeString('en-GB', { hour12: false });
      setDateTime(`${dateStr} | ${timeStr}`);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Analysis Countdown Logic
  useEffect(() => {
    let interval: any;
    if (isAnalyzing && analysisTimer > 0) {
      interval = setInterval(() => {
        setAnalysisTimer(prev => prev - 1);
      }, 1000);
    } else if (isAnalyzing && analysisTimer === 0) {
      setIsAnalyzing(false);
      setHasAnalysed(true); 
    }
    return () => clearInterval(interval);
  }, [isAnalyzing, analysisTimer]);

  /**
   * LIVE CYBER LOG GENERATOR
   * Logic: Only generate "Threat" style logs if the 30s analysis (hasAnalysed) is complete.
   * Before that, logs appear "Normal" even if a suspicious node is selected.
   */
  useEffect(() => {
    if (!isEntered) return;

    const generateLog = () => {
      // Determine if we should show suspicious logs
      // Only show suspicious logs if we are NOT analyzing AND have already finished a scan
      const showSuspicious = hasAnalysed && activeScenarioLabel !== 'SAFE';

      const newLog: CyberLog = {
        time: new Date().toLocaleTimeString('en-GB', { hour12: false }),
        user: MOCK_USERS[Math.floor(Math.random() * MOCK_USERS.length)],
        action: MOCK_ACTIONS[Math.floor(Math.random() * MOCK_ACTIONS.length)],
        status: (showSuspicious && Math.random() > 0.4) ? 'Failed' : (Math.random() > 0.1 ? 'Success' : 'Failed'),
        oddHour: showSuspicious
      };

      setScenario(prev => ({
        ...prev,
        cyber: {
          ...prev.cyber,
          logs: [newLog, ...prev.cyber.logs].slice(0, 30)
        }
      }));
    };

    const interval = setInterval(generateLog, (hasAnalysed && activeScenarioLabel === 'THREAT') ? 1200 : 4000);
    return () => clearInterval(interval);
  }, [isEntered, activeScenarioLabel, hasAnalysed]);

  const calculateCompoundRisk = (physical: number, cyber: number, anomalyCount: number) => {
    const score = (physical * 0.4) + (cyber * 0.5) + (Math.min(anomalyCount * 5, 10));
    const finalScore = Math.min(Math.round(score), 100);
    return {
      score: finalScore,
      category: finalScore > 70 ? 'HIGH' as const : finalScore > 30 ? 'MEDIUM' as const : 'LOW' as const,
      color: finalScore > 70 ? THEMES['CRIMSON ALERT'].primary : finalScore > 30 ? THEMES['AMBER TACTICAL'].primary : THEMES['NIGHT VISION'].primary
    };
  };

  const handleToggleConfig = (key: keyof SystemConfig) => {
    setSystemConfig(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleEmergencyLockdown = () => {
    setIsSettingsOpen(false);
    handleScenarioChange('threat');
    setActiveTheme('CRIMSON ALERT');
  };

  const handleScenarioChange = (type: 'normal' | 'suspicious' | 'threat') => {
    const label = type === 'normal' ? 'SAFE' : type.toUpperCase();
    setActiveScenarioLabel(label);
    setIsConnecting(true);
    setHasAnalysed(false); 
    setAnalysisTimer(0);
    setIsAnalyzing(false);
    
    setTimeout(() => {
      let base = type === 'normal' ? NORMAL_SCENARIO : type === 'suspicious' ? SUSPICIOUS_SCENARIO : THREAT_SCENARIO;
      const stats = calculateCompoundRisk(base.risk.physicalScore, base.risk.cyberScore, base.cyber.anomalies);
      
      setScenario(prev => ({ 
        ...base, 
        camera: {
          ...base.camera,
          stream: cameraStream || undefined,
          isLive: !!cameraStream
        },
        cyber: {
          ...base.cyber,
          logs: prev.cyber.logs 
        },
        risk: { 
          ...base.risk, 
          ...stats 
        } 
      }));
      
      setIsConnecting(false);
    }, 500);
  };

  const startCamera = async (mode: 'user' | 'environment') => {
    setIsConnecting(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: mode, width: { ideal: 1280 }, height: { ideal: 720 } } 
      });
      setCameraStream(stream);
      setScenario(prev => ({ 
        ...prev, 
        camera: { 
          ...prev.camera, 
          stream, 
          isLive: true, 
          behaviour: activeScenarioLabel === 'SAFE' ? 'LIVE FEED' : prev.camera.behaviour, 
          time: new Date().toLocaleTimeString() 
        } 
      }));
    } catch (err) { 
      console.error(err);
      alert("Camera Uplink Failed. Access denied."); 
    }
    setIsConnecting(false);
  };

  const handleToggleLiveCamera = async () => {
    if (cameraStream) {
      if (isRecording) handleToggleRecording();
      cameraStream.getTracks().forEach(t => t.stop());
      setCameraStream(null);
      setScenario(prev => ({ ...prev, camera: { ...prev.camera, stream: undefined, isLive: false } }));
    } else {
      await startCamera(facingMode);
    }
  };

  const handleSwitchCamera = async () => {
    const newMode = facingMode === 'user' ? 'environment' : 'user';
    setFacingMode(newMode);
    if (cameraStream) {
      if (isRecording) handleToggleRecording();
      cameraStream.getTracks().forEach(t => t.stop());
      await startCamera(newMode);
    }
  };

  const runAiAnalysis = async () => {
    if (!cameraStream || isAnalyzing) return;
    setIsAnalyzing(true);
    setHasAnalysed(false);
    setAnalysisTimer(30); 
  };

  const handleToggleRecording = () => {
    if (!cameraStream) return;

    if (isRecording) {
      mediaRecorderRef.current?.stop();
      setIsRecording(false);
    } else {
      recordedChunksRef.current = [];
      const options = { mimeType: 'video/webm; codecs=vp9' };
      const recorder = new MediaRecorder(cameraStream, options);

      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          recordedChunksRef.current.push(event.data);
        }
      };

      recorder.onstop = () => {
        const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = `KAVACH_RECORDING_${new Date().getTime()}.webm`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
      };

      recorder.start();
      mediaRecorderRef.current = recorder;
      setIsRecording(true);
    }
  };

  const handleOpenIntelReport = () => {
    setIsExporting(true);
    setTimeout(() => {
      setIsExporting(false);
      setShowReport(true);
    }, 2000);
  };

  if (!isEntered) return <EntryScreen onEnter={(id) => { if(id) setOperatorId(id); setIsEntered(true); }} />;

  return (
    <div className="min-h-screen bg-grid bg-[#0A0E27] text-white transition-all duration-500 overflow-x-hidden">
      <Header dateTime={dateTime} isThreat={scenario.risk.score > 40} activeScenarioLabel={activeScenarioLabel} onLogoClick={() => setIsSettingsOpen(true)} />
      
      <SettingsModal 
        isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} 
        operatorId={operatorId} activeTheme={activeTheme} onThemeChange={setActiveTheme}
        config={systemConfig} onToggleConfig={handleToggleConfig} onEmergencyLockdown={handleEmergencyLockdown}
      />

      <main className="w-full max-w-[1600px] mx-auto p-4 md:p-8 space-y-6 md:space-y-8 pb-40 animate-[fadeIn_0.5s]">
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 md:gap-8">
          <CameraPanel 
            data={scenario.camera} 
            isAnalyzing={isAnalyzing} 
            isConnecting={isConnecting} 
            isUserFacing={facingMode === 'user'}
            isRecording={isRecording}
          />
          <CyberLogPanel 
            cyber={scenario.cyber} 
            isAlert={scenario.risk.score > 40} 
            isAnalyzing={isAnalyzing}
            hasAnalysed={hasAnalysed}
            analysisTimer={analysisTimer}
          />
          <RiskGauge data={scenario.risk} />
          <AlertPanel data={scenario.alert} onDismiss={() => setScenario(prev => ({ ...prev, risk: { ...prev.risk, score: 5 } }))} />
        </div>
      </main>

      <ControlPanel 
        activeScenarioLabel={activeScenarioLabel}
        isAnalyzing={isAnalyzing}
        hasAnalysed={hasAnalysed}
        analysisTimer={analysisTimer}
        onAnalyzeNormal={() => handleScenarioChange('normal')} 
        onAnalyzeSuspicious={() => handleScenarioChange('suspicious')} 
        onSimulateThreat={() => handleScenarioChange('threat')} 
        onToggleLive={handleToggleLiveCamera} 
        onSwitchCamera={handleSwitchCamera}
        onRunAI={runAiAnalysis}
        onToggleRecording={handleToggleRecording}
        isRecording={isRecording}
        isLive={!!cameraStream} 
        onUpload={handleOpenIntelReport} 
        onReset={() => setIsEntered(false)} 
        isExporting={isExporting}
      />

      {isExporting && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/90 backdrop-blur-md px-4">
          <div className="panel-blur border border-[var(--primary)] p-8 md:p-12 rounded-3xl text-center max-w-sm w-full">
            <i className="fa-solid fa-file-pdf text-5xl text-[var(--primary)] mb-6 animate-bounce"></i>
            <h3 className="font-orbitron font-black text-xl text-[var(--primary)] uppercase tracking-widest">Generating Intel Report</h3>
            <p className="font-rajdhani text-[#94A3C2] text-sm mt-4 uppercase tracking-widest">Compiling biometric and network logs...</p>
          </div>
        </div>
      )}

      {showReport && (
        <ForensicReport 
          scenario={scenario} 
          operatorId={operatorId} 
          onClose={() => setShowReport(false)} 
        />
      )}
    </div>
  );
};

export default App;

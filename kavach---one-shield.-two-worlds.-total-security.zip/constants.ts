
import { Scenario, UserProfile, CyberLog } from './types';

const MOCK_PROFILES: Record<string, UserProfile> = {
  'officer_12': {
    fullName: "Arjun Sharma",
    phone: "+91 98765 43210",
    email: "a.sharma@kavach.gov.in",
    address: "Block 4, Defense Colony, New Delhi, India",
    joinedDate: "12 Jan 2021",
    totalAccesses: 1422,
    recentAccessTimes: ["09:15", "09:18", "Yesterday 18:40", "Yesterday 14:20", "Yesterday 09:00"]
  },
  'admin_user': {
    fullName: "Vikram Malhotra",
    phone: "+91 91234 56789",
    email: "v.malhotra@kavach.gov.in",
    address: "Suite 201, Officers Mess, Western Command",
    joinedDate: "05 Mar 2019",
    totalAccesses: 8540,
    recentAccessTimes: ["10:23", "08:12", "07:55", "Yesterday 23:10", "Yesterday 21:00"]
  },
  'officer_07': {
    fullName: "Priya Kaur",
    phone: "+91 99887 76655",
    email: "p.kaur@kavach.gov.in",
    address: "Quarter 8B, Air Force Station, Palam",
    joinedDate: "22 Nov 2022",
    totalAccesses: 630,
    recentAccessTimes: ["11:45", "10:10", "Yesterday 17:30", "Yesterday 16:15", "Yesterday 08:45"]
  },
  'security_ops': {
    fullName: "Sanjay Gupta",
    phone: "+91 90000 11111",
    email: "s.gupta@kavach.gov.in",
    address: "NCR Coordination Hub, Level 2, Sector 44",
    joinedDate: "15 Aug 2020",
    totalAccesses: 3210,
    recentAccessTimes: ["14:22", "13:05", "11:50", "10:30", "09:15"]
  },
  'unknown_ip': {
    fullName: "EXTERNAL SOURCE",
    phone: "N/A",
    email: "IP: 192.168.1.104",
    address: "Geolocated: Unknown Origin (Proxy Detected)",
    joinedDate: "N/A",
    totalAccesses: 14,
    recentAccessTimes: ["23:08", "23:09", "23:10", "23:11", "23:12"]
  }
};

// Generator for historical data
const generateHistoricalLogs = (count: number, daysBack: number): CyberLog[] => {
  const actions = ["Login: Secure Port", "Database Query", "File Download", "Config Change", "Satellite Ping"];
  const users = Object.keys(MOCK_PROFILES);
  const logs: CyberLog[] = [];
  
  for (let i = 0; i < count; i++) {
    const date = new Date();
    date.setDate(date.getDate() - Math.floor(Math.random() * daysBack));
    const hours = Math.floor(Math.random() * 24).toString().padStart(2, '0');
    const mins = Math.floor(Math.random() * 60).toString().padStart(2, '0');
    const user = users[Math.floor(Math.random() * users.length)];
    
    logs.push({
      date: date.toLocaleDateString('en-GB'),
      time: `${hours}:${mins}:00`,
      user: user,
      action: actions[Math.floor(Math.random() * actions.length)],
      status: Math.random() > 0.05 ? "Success" : "Failed",
      profile: MOCK_PROFILES[user]
    });
  }
  return logs.sort((a, b) => b.time.localeCompare(a.time));
};

export const HISTORICAL_DATA = {
  WEEK: generateHistoricalLogs(25, 7),
  MONTH: generateHistoricalLogs(60, 30),
  YEAR: generateHistoricalLogs(150, 365)
};

export const NORMAL_SCENARIO: Scenario = {
  camera: {
    status: 'normal',
    behaviour: 'NOMINAL FLOW',
    time: '14:32:18',
    confidence: 98.4,
    mode: 'LIVE'
  },
  cyber: {
    status: 'normal',
    logs: [
      { time: "09:15:23", user: "officer_12", action: "Login: Secure Port", status: "Success", profile: MOCK_PROFILES['officer_12'] },
      { time: "09:18:45", user: "officer_12", action: "Encrypted Log Access", status: "Success", profile: MOCK_PROFILES['officer_12'] },
      { time: "10:23:12", user: "admin_user", action: "Hardware Integrity Check", status: "Success", profile: MOCK_PROFILES['admin_user'] },
      { time: "11:45:33", user: "officer_07", action: "Satellite Uplink Heartbeat", status: "Success", profile: MOCK_PROFILES['officer_07'] },
      { time: "14:22:18", user: "security_ops", action: "Routine Config Sync", status: "Success", profile: MOCK_PROFILES['security_ops'] }
    ],
    anomalies: 0
  },
  risk: {
    score: 8,
    physicalScore: 5,
    cyberScore: 11,
    category: "LOW",
    color: "#00FF88"
  },
  alert: {
    severity: "low",
    title: "OPERATIONAL INTEGRITY: 100%",
    subtitle: "Perimeter and Network Normalized",
    reasons: [
      "Perimeter sensors reporting zero movement anomalies",
      "Network traffic within +/- 2% baseline variance",
      "All active personnel biometric signatures verified"
    ],
    actionRequired: false,
    explainability: "No cyber anomalies + normal visual behaviour = LOW RISK.",
    recommendedAction: "Maintain standard watch. No immediate intervention required."
  }
};

export const SUSPICIOUS_SCENARIO: Scenario = {
  camera: {
    status: 'suspicious',
    behaviour: 'PERSON LOITERING NEAR RESTRICTED ZONE',
    time: '23:11:05',
    confidence: 82.1,
    mode: 'LIVE'
  },
  cyber: {
    status: 'suspicious',
    logs: [
      { time: "23:08:12", user: "unknown_ip", action: "Port Scan: SSH (22)", status: "Failed", profile: MOCK_PROFILES['unknown_ip'] },
      { time: "23:09:45", user: "officer_07", action: "Unauthorized IP Login", status: "Failed", profile: MOCK_PROFILES['officer_07'] },
      { time: "23:10:11", user: "guest_sys", action: "Database Query: 'User_List'", status: "Success", oddHour: true },
      { time: "23:10:55", user: "unknown_ip", action: "ICMP Ping Flood", status: "Failed", profile: MOCK_PROFILES['unknown_ip'] },
      { time: "23:11:20", user: "security_ops", action: "Firewall Auto-Rule Applied", status: "Success", profile: MOCK_PROFILES['security_ops'] }
    ],
    anomalies: 4
  },
  risk: {
    score: 42,
    physicalScore: 35,
    cyberScore: 49,
    category: "MEDIUM",
    color: "#FFB800"
  },
  alert: {
    severity: "low",
    title: "PRELIMINARY ANOMALY DETECTED",
    subtitle: "Potential Reconnaissance in Progress",
    reasons: [
      { type: "warning", text: "Physical: Multiple individuals detected in secure lobby" },
      { type: "warning", text: "Cyber: Failed logins at odd hours from unknown users" },
      { type: "info", text: "System: Automated countermeasures initiated (IP Throttling)" }
    ],
    actionRequired: false,
    explainability: "Unusual login times + persistent loitering = MEDIUM RISK.",
    recommendedAction: "Initiate secondary verification protocol. Increase physical surveillance in Zone-B and deploy rapid response drones."
  }
};

export const THREAT_SCENARIO: Scenario = {
  camera: {
    status: 'suspicious',
    behaviour: 'WEAPON LIKE OBJECT DETECTED',
    time: '03:24:37',
    confidence: 96.5,
    mode: 'LIVE'
  },
  cyber: {
    status: 'suspicious',
    logs: [
      { time: "03:24:15", user: "admin_root", action: "Brute Force Attack", status: "Failed" },
      { time: "03:24:42", user: "admin_root", action: "Privilege Escalation", status: "Failed" },
      { time: "03:25:01", user: "system_kernel", action: "Core Kernel Rewrite Attempt", status: "Failed" },
      { time: "02:18:33", user: "sys_remote", action: "Lateral Movement Detected", status: "Failed", oddHour: true },
      { time: "03:26:12", user: "unknown_ip", action: "RDP Tunneling Attempt", status: "Failed", profile: MOCK_PROFILES['unknown_ip'] }
    ],
    anomalies: 12
  },
  risk: {
    score: 89,
    physicalScore: 92,
    cyberScore: 86,
    category: "HIGH",
    color: "#FF3366"
  },
  alert: {
    severity: "high",
    title: "POTENTIAL BREACH DETECTED!",
    subtitle: "Level 1 Intrusion Countermeasures Required",
    reasons: [
      { type: "danger", text: "Physical: High-velocity movement detected in Zone A-12" },
      { type: "danger", text: "Cyber: Active Brute Force attack on kernel detected" },
      { type: "danger", text: "Tactical: Probable weapon signature identified in quadrant 4" }
    ],
    actionRequired: true,
    explainability: "Active breach attempt + tactical weapon detection = HIGH RISK.",
    recommendedAction: "Engage Level 1 response teams. Lock down all primary entry points, isolate core network segments, and initiate local signal jamming."
  }
};
